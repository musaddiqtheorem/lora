export type FlowStatus =
  | "draft"
  | "uploading"
  | "captioning"
  | "ready"
  | "training"
  | "complete"
  | "failed";

export interface AiGuidance {
  recommended_image_count: number;
  shot_types: string[];
  suggested_trigger_word: string;
  background_tips: string;
  lighting_tips: string;
  common_mistakes: string[];
  estimated_training_steps: number;
}

export interface TrainingConfig {
  steps: number;
  learning_rate: number;
  batch_size: number;
}

export interface LoraFlow {
  id: string;
  user_id: string;
  vision: string;
  theme: string;
  trigger_word: string;
  status: FlowStatus;
  ai_guidance: AiGuidance | null;
  training_config: TrainingConfig;
  fal_job_id: string | null;
  lora_url: string | null;
  training_started_at: string | null;
  training_completed_at: string | null;
  estimated_duration_sec: number | null;
  error_message: string | null;
  created_at: string;
  updated_at: string;
}

export interface FlowImage {
  id: string;
  flow_id: string;
  storage_path: string;
  public_url: string;
  original_filename: string;
  caption: string;
  ai_draft_caption: string | null;
  sort_order: number;
  created_at: string;
}

export interface LoraTest {
  id: string;
  flow_id: string;
  prompt: string;
  result_url: string;
  model_used: string;
  created_at: string;
}

// API request/response types

export interface CreateFlowRequest {
  vision: string;
  theme: string;
  trigger_word?: string;
}

export interface UpdateFlowRequest {
  vision?: string;
  theme?: string;
  trigger_word?: string;
  status?: FlowStatus;
  ai_guidance?: AiGuidance;
  training_config?: Partial<TrainingConfig>;
  fal_job_id?: string;
  lora_url?: string;
  training_started_at?: string;
  training_completed_at?: string;
  estimated_duration_sec?: number;
  error_message?: string;
}

export interface GuidanceRequest {
  vision: string;
  theme: string;
}

export interface CaptionsRequest {
  flow_id: string;
  trigger_word: string;
  theme: string;
  images: Array<{ id: string; public_url: string }>;
}

export interface CaptionResult {
  image_id: string;
  caption: string;
}

export interface StartTrainingRequest {
  flow_id: string;
}

export interface TrainingStatusResponse {
  status: FlowStatus;
  progress_percentage: number | null;
  estimated_remaining_sec: number | null;
}

export interface FalWebhookPayload {
  request_id: string;
  status: "OK" | "ERROR";
  payload: {
    diffusers_lora_file?: { url: string };
    config_file?: { url: string };
    error?: string;
  };
}

export interface GenerateTestRequest {
  flow_id: string;
  prompt: string;
  model?: string;
  lora_scale?: number;
}

export interface GenerateTestResponse {
  result_url: string;
  test_id: string;
}
