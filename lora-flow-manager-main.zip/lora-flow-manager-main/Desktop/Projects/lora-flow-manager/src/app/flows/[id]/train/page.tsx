"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { FlowStepper } from "@/components/FlowStepper";
import { Button } from "@/components/ui/Button";
import {
  TRAINING_STEPS_MIN,
  TRAINING_STEPS_MAX,
  TRAINING_STEPS_DEFAULT,
  TRAINING_POLL_INTERVAL_MS,
  estimateTrainingTime,
  estimateTrainingCost,
} from "@/lib/constants";
import type { LoraFlow, TrainingStatusResponse } from "@/types";

export default function TrainPage() {
  const params = useParams<{ id: string }>();
  const flowId = params.id;
  const router = useRouter();
  const supabase = createClient();

  const [flow, setFlow] = useState<LoraFlow | null>(null);
  const [imageCount, setImageCount] = useState(0);
  const [pageLoading, setPageLoading] = useState(true);

  // Config state (pre-training)
  const [steps, setSteps] = useState(TRAINING_STEPS_DEFAULT);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [learningRate, setLearningRate] = useState(0.0001);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [starting, setStarting] = useState(false);
  const [startError, setStartError] = useState("");

  // Training state
  const [trainingStatus, setTrainingStatus] = useState<TrainingStatusResponse | null>(null);
  const [elapsedSec, setElapsedSec] = useState(0);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const realtimeRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  // Copy state
  const [copied, setCopied] = useState(false);

  // Load flow + image count
  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push("/login"); return; }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: flowData } = await (supabase as any)
        .from("lora_flows")
        .select("*")
        .eq("id", flowId)
        .single();

      if (!flowData) { router.push("/"); return; }
      const f = flowData as LoraFlow;
      setFlow(f);

      // Sync steps from stored config
      if (f.training_config?.steps) setSteps(f.training_config.steps);
      if (f.training_config?.learning_rate) setLearningRate(f.training_config.learning_rate);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { count } = await (supabase as any)
        .from("flow_images")
        .select("*", { count: "exact", head: true })
        .eq("flow_id", flowId);

      setImageCount(count ?? 0);
      setPageLoading(false);
    }
    load();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flowId]);

  // Poll + Realtime when training
  const pollStatus = useCallback(async () => {
    const res = await fetch(`/api/training/status?flow_id=${flowId}`);
    if (!res.ok) return;
    const data: TrainingStatusResponse = await res.json();
    setTrainingStatus(data);

    // Update local flow status if terminal
    if (data.status === "complete" || data.status === "failed") {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: freshFlow } = await (supabase as any)
        .from("lora_flows")
        .select("*")
        .eq("id", flowId)
        .single();
      if (freshFlow) setFlow(freshFlow as LoraFlow);
      clearIntervalAndChannel();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flowId]);

  function clearIntervalAndChannel() {
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
    if (realtimeRef.current) { supabase.removeChannel(realtimeRef.current); realtimeRef.current = null; }
  }

  useEffect(() => {
    if (!flow) return;
    if (flow.status !== "training") return;

    // Start elapsed timer
    const startedAt = flow.training_started_at ? new Date(flow.training_started_at).getTime() : Date.now();
    const ticker = setInterval(() => {
      setElapsedSec(Math.floor((Date.now() - startedAt) / 1000));
    }, 1000);

    // Poll every 30s
    pollStatus();
    pollRef.current = setInterval(pollStatus, TRAINING_POLL_INTERVAL_MS);

    // Realtime subscription
    const channel = supabase
      .channel(`train-${flowId}`)
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .on("postgres_changes" as any, {
        event: "UPDATE",
        schema: "public",
        table: "lora_flows",
        filter: `id=eq.${flowId}`,
      }, (payload: { new: LoraFlow }) => {
        const updated = payload.new as LoraFlow;
        setFlow(updated);
        if (updated.status === "complete" || updated.status === "failed") {
          clearIntervalAndChannel();
          clearInterval(ticker);
        }
      })
      .subscribe();

    realtimeRef.current = channel;

    return () => {
      clearInterval(ticker);
      clearIntervalAndChannel();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flow?.status, flowId]);

  async function handleStartTraining() {
    setStarting(true);
    setStartError("");

    // Save config first
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any)
      .from("lora_flows")
      .update({
        training_config: { steps, learning_rate: learningRate, batch_size: 1 },
        updated_at: new Date().toISOString(),
      })
      .eq("id", flowId);

    const res = await fetch("/api/training/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ flow_id: flowId }),
    });
    const json = await res.json();

    if (!res.ok) {
      setStartError(json.error ?? "Failed to start training");
      setStarting(false);
      setConfirmOpen(false);
      return;
    }

    // Refresh flow
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: freshFlow } = await (supabase as any)
      .from("lora_flows")
      .select("*")
      .eq("id", flowId)
      .single();

    if (freshFlow) setFlow(freshFlow as LoraFlow);
    setConfirmOpen(false);
    setStarting(false);
  }

  async function handleRetry() {
    // Reset status to ready, then allow re-submit
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any)
      .from("lora_flows")
      .update({ status: "ready", error_message: null, fal_job_id: null, updated_at: new Date().toISOString() })
      .eq("id", flowId);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: freshFlow } = await (supabase as any)
      .from("lora_flows")
      .select("*")
      .eq("id", flowId)
      .single();
    if (freshFlow) setFlow(freshFlow as LoraFlow);
  }

  async function copyLoraUrl() {
    if (!flow?.lora_url) return;
    await navigator.clipboard.writeText(flow.lora_url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  if (pageLoading) return <PageSkeleton />;
  if (!flow) return null;

  const estimatedSec = estimateTrainingTime(steps, imageCount);
  const estimatedCost = estimateTrainingCost(steps);

  // Determine which panel to show
  const status = flow.status;

  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      <FlowStepper flowId={flowId} currentStep={4} />

      {/* Pre-training */}
      {(status === "ready" || status === "captioning" || status === "draft" || status === "uploading") && (
        <PreTrainingPanel
          flow={flow}
          imageCount={imageCount}
          steps={steps}
          onStepsChange={setSteps}
          learningRate={learningRate}
          onLearningRateChange={setLearningRate}
          showAdvanced={showAdvanced}
          onToggleAdvanced={() => setShowAdvanced((v) => !v)}
          estimatedSec={estimatedSec}
          estimatedCost={estimatedCost}
          onStart={() => setConfirmOpen(true)}
          startError={startError}
        />
      )}

      {/* Training in progress */}
      {status === "training" && (
        <TrainingProgressPanel
          flow={flow}
          elapsedSec={elapsedSec}
          trainingStatus={trainingStatus}
        />
      )}

      {/* Complete */}
      {status === "complete" && (
        <CompletePanel
          flow={flow}
          copied={copied}
          onCopy={copyLoraUrl}
          onTest={() => router.push(`/flows/${flowId}/test`)}
        />
      )}

      {/* Failed */}
      {status === "failed" && (
        <FailedPanel
          flow={flow}
          onRetry={handleRetry}
        />
      )}

      {/* Confirmation modal */}
      {confirmOpen && (
        <ConfirmModal
          steps={steps}
          estimatedCost={estimatedCost}
          estimatedSec={estimatedSec}
          loading={starting}
          onConfirm={handleStartTraining}
          onCancel={() => setConfirmOpen(false)}
        />
      )}
    </div>
  );
}

// ---- Sub-panels ------------------------------------------------------------

function PreTrainingPanel({
  flow,
  imageCount,
  steps,
  onStepsChange,
  learningRate,
  onLearningRateChange,
  showAdvanced,
  onToggleAdvanced,
  estimatedSec,
  estimatedCost,
  onStart,
  startError,
}: {
  flow: LoraFlow;
  imageCount: number;
  steps: number;
  onStepsChange: (v: number) => void;
  learningRate: number;
  onLearningRateChange: (v: number) => void;
  showAdvanced: boolean;
  onToggleAdvanced: () => void;
  estimatedSec: number;
  estimatedCost: number;
  onStart: () => void;
  startError: string;
}) {
  return (
    <>
      <div>
        <h1 className="text-xl font-bold tracking-tight" style={{ color: "var(--color-text-primary)" }}>
          Configure Training
        </h1>
        <p className="mt-1 text-sm" style={{ color: "var(--color-text-secondary)" }}>
          Review your settings before submitting to fal.ai.
        </p>
      </div>

      {/* Flow summary */}
      <div
        className="rounded-lg px-4 py-3 flex flex-wrap gap-x-6 gap-y-2"
        style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-border)" }}
      >
        <SummaryItem label="Trigger word" value={flow.trigger_word} mono />
        <SummaryItem label="Theme" value={flow.theme} />
        <SummaryItem label="Images" value={String(imageCount)} />
      </div>

      {/* Steps slider */}
      <div className="flex flex-col gap-4 rounded-lg px-4 py-4" style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-border)" }}>
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
              Training Steps
            </label>
            <span
              className="text-sm font-semibold tabular-nums px-2 py-0.5 rounded"
              style={{ backgroundColor: "var(--color-accent-light)", color: "var(--color-accent)" }}
            >
              {steps.toLocaleString()}
            </span>
          </div>
          <input
            type="range"
            min={TRAINING_STEPS_MIN}
            max={TRAINING_STEPS_MAX}
            step={100}
            value={steps}
            onChange={(e) => onStepsChange(Number(e.target.value))}
            className="w-full accent-indigo-600"
          />
          <div className="flex justify-between text-xs" style={{ color: "var(--color-text-muted)" }}>
            <span>{TRAINING_STEPS_MIN.toLocaleString()} (fast)</span>
            <span>{TRAINING_STEPS_MAX.toLocaleString()} (quality)</span>
          </div>
        </div>

        {/* Estimates */}
        <div className="flex gap-6 flex-wrap">
          <EstimateChip label="Est. time" value={formatDuration(estimatedSec)} />
          <EstimateChip label="Est. cost" value={`$${estimatedCost.toFixed(2)}`} />
        </div>

        {/* Advanced toggle */}
        <button
          type="button"
          onClick={onToggleAdvanced}
          className="self-start text-xs underline underline-offset-2 transition-opacity hover:opacity-70"
          style={{ color: "var(--color-text-secondary)" }}
        >
          {showAdvanced ? "Hide advanced" : "Show advanced"}
        </button>

        {showAdvanced && (
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
              Learning Rate
            </label>
            <select
              value={learningRate}
              onChange={(e) => onLearningRateChange(Number(e.target.value))}
              className="rounded-md px-3 py-2 text-sm w-48 outline-none"
              style={{
                backgroundColor: "var(--color-background)",
                border: "1px solid var(--color-border-strong)",
                color: "var(--color-text-primary)",
              }}
            >
              <option value={0.0002}>0.0002 (high)</option>
              <option value={0.0001}>0.0001 (default)</option>
              <option value={0.00005}>0.00005 (low)</option>
            </select>
          </div>
        )}
      </div>

      {startError && (
        <p className="text-sm" style={{ color: "var(--color-status-failed-text)" }}>
          {startError}
        </p>
      )}

      <div className="flex items-center justify-between">
        <Button variant="ghost" size="md" onClick={() => {}}>
          {/* noop — handled by router if needed */}
        </Button>
        <Button size="md" onClick={onStart}>
          Start Training →
        </Button>
      </div>
    </>
  );
}

function TrainingProgressPanel({
  flow,
  elapsedSec,
  trainingStatus,
}: {
  flow: LoraFlow;
  elapsedSec: number;
  trainingStatus: TrainingStatusResponse | null;
}) {
  const progress = trainingStatus?.progress_percentage ?? null;
  const estimatedRemaining = trainingStatus?.estimated_remaining_sec ?? null;

  return (
    <>
      <div>
        <h1 className="text-xl font-bold tracking-tight" style={{ color: "var(--color-text-primary)" }}>
          Training in Progress
        </h1>
        <p className="mt-1 text-sm" style={{ color: "var(--color-text-secondary)" }}>
          Your LoRA is being trained on fal.ai. This page will update automatically.
        </p>
      </div>

      {/* Progress card */}
      <div
        className="rounded-lg px-6 py-8 flex flex-col items-center gap-6"
        style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-border)" }}
      >
        {/* Circular progress */}
        <CircularProgress pct={progress ?? 0} />

        {/* Activity indicator */}
        <div className="flex items-center gap-2">
          <span
            className="h-2 w-2 rounded-full animate-pulse"
            style={{ backgroundColor: "var(--color-accent)" }}
          />
          <span className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
            Training {flow.trigger_word}…
          </span>
        </div>

        {/* Time stats */}
        <div className="flex gap-8">
          <EstimateChip label="Elapsed" value={formatDuration(elapsedSec)} />
          {estimatedRemaining !== null && (
            <EstimateChip label="Est. remaining" value={formatDuration(estimatedRemaining)} />
          )}
        </div>

        <p className="text-xs text-center max-w-sm" style={{ color: "var(--color-text-muted)" }}>
          We&apos;ll update this page automatically via webhooks. You can safely leave and come back.
        </p>
      </div>
    </>
  );
}

function CompletePanel({
  flow,
  copied,
  onCopy,
  onTest,
}: {
  flow: LoraFlow;
  copied: boolean;
  onCopy: () => void;
  onTest: () => void;
}) {
  const startedAt = flow.training_started_at ? new Date(flow.training_started_at) : null;
  const completedAt = flow.training_completed_at ? new Date(flow.training_completed_at) : null;
  const durationSec =
    startedAt && completedAt
      ? Math.floor((completedAt.getTime() - startedAt.getTime()) / 1000)
      : null;

  return (
    <>
      <div>
        <h1 className="text-xl font-bold tracking-tight" style={{ color: "var(--color-status-ready-text)" }}>
          ✓ Training Complete
        </h1>
        <p className="mt-1 text-sm" style={{ color: "var(--color-text-secondary)" }}>
          Your LoRA is ready to use.
          {durationSec !== null && ` Training took ${formatDuration(durationSec)}.`}
        </p>
      </div>

      <div
        className="rounded-lg px-4 py-4 flex flex-col gap-3"
        style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-border)" }}
      >
        <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--color-text-muted)" }}>
          LoRA URL
        </p>
        <div className="flex items-center gap-2 flex-wrap">
          <code
            className="flex-1 rounded-md px-3 py-2 text-xs break-all"
            style={{
              fontFamily: "var(--font-mono)",
              backgroundColor: "var(--color-background)",
              border: "1px solid var(--color-border-strong)",
              color: "var(--color-text-primary)",
            }}
          >
            {flow.lora_url}
          </code>
          <Button variant="secondary" size="sm" onClick={onCopy}>
            {copied ? "Copied!" : "Copy"}
          </Button>
        </div>
      </div>

      <div className="flex justify-end">
        <Button size="md" onClick={onTest}>
          Test Your LoRA →
        </Button>
      </div>
    </>
  );
}

function FailedPanel({
  flow,
  onRetry,
}: {
  flow: LoraFlow;
  onRetry: () => void;
}) {
  return (
    <>
      <div>
        <h1 className="text-xl font-bold tracking-tight" style={{ color: "var(--color-status-failed-text)" }}>
          Training Failed
        </h1>
        <p className="mt-1 text-sm" style={{ color: "var(--color-text-secondary)" }}>
          Something went wrong during training.
        </p>
      </div>

      {flow.error_message && (
        <div
          className="rounded-lg px-4 py-3 text-sm"
          style={{
            backgroundColor: "var(--color-status-failed-bg)",
            border: "1px solid var(--color-status-failed-border)",
            color: "var(--color-status-failed-text)",
          }}
        >
          {flow.error_message}
        </div>
      )}

      <div className="flex justify-end">
        <Button variant="secondary" size="md" onClick={onRetry}>
          Retry Training
        </Button>
      </div>
    </>
  );
}

// ---- Confirm modal ---------------------------------------------------------

function ConfirmModal({
  steps,
  estimatedCost,
  estimatedSec,
  loading,
  onConfirm,
  onCancel,
}: {
  steps: number;
  estimatedCost: number;
  estimatedSec: number;
  loading: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
      <div
        className="w-full max-w-sm rounded-xl p-6 flex flex-col gap-4"
        style={{ backgroundColor: "var(--color-surface)", border: "1px solid var(--color-border)" }}
      >
        <h2 className="text-lg font-bold" style={{ color: "var(--color-text-primary)" }}>
          Start Training?
        </h2>
        <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
          This will submit your images to fal.ai for training.
        </p>
        <div className="flex gap-6">
          <EstimateChip label="Steps" value={steps.toLocaleString()} />
          <EstimateChip label="Est. cost" value={`$${estimatedCost.toFixed(2)}`} />
          <EstimateChip label="Est. time" value={formatDuration(estimatedSec)} />
        </div>
        <div className="flex gap-3 justify-end mt-2">
          <Button variant="ghost" size="md" onClick={onCancel} disabled={loading}>
            Cancel
          </Button>
          <Button size="md" loading={loading} onClick={onConfirm}>
            Confirm & Start
          </Button>
        </div>
      </div>
    </div>
  );
}

// ---- Local helpers ---------------------------------------------------------

function SummaryItem({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-xs" style={{ color: "var(--color-text-muted)" }}>{label}</span>
      <span
        className="text-sm font-semibold"
        style={{
          color: "var(--color-text-primary)",
          fontFamily: mono ? "var(--font-mono)" : "inherit",
        }}
      >
        {value}
      </span>
    </div>
  );
}

function EstimateChip({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-xs" style={{ color: "var(--color-text-muted)" }}>{label}</span>
      <span className="text-sm font-semibold tabular-nums" style={{ color: "var(--color-text-primary)" }}>
        {value}
      </span>
    </div>
  );
}

function CircularProgress({ pct }: { pct: number }) {
  const r = 44;
  const circumference = 2 * Math.PI * r;
  const offset = circumference - (pct / 100) * circumference;

  return (
    <div className="relative h-28 w-28 flex items-center justify-center">
      <svg className="absolute inset-0 -rotate-90" viewBox="0 0 100 100">
        <circle
          cx="50" cy="50" r={r}
          fill="none"
          strokeWidth="8"
          stroke="var(--color-border)"
        />
        <circle
          cx="50" cy="50" r={r}
          fill="none"
          strokeWidth="8"
          stroke="var(--color-accent)"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 1s ease" }}
        />
      </svg>
      <span className="text-xl font-bold tabular-nums" style={{ color: "var(--color-text-primary)" }}>
        {pct}%
      </span>
    </div>
  );
}

function formatDuration(sec: number): string {
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return s > 0 ? `${m}m ${s}s` : `${m}m`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm > 0 ? `${h}h ${rm}m` : `${h}h`;
}

function PageSkeleton() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      <div className="h-8 rounded animate-pulse w-full" style={{ backgroundColor: "var(--color-border)" }} />
      <div className="h-6 rounded animate-pulse w-1/2" style={{ backgroundColor: "var(--color-border)" }} />
      <div className="h-48 rounded-lg animate-pulse" style={{ backgroundColor: "var(--color-border)" }} />
    </div>
  );
}
