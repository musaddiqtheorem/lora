"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { Input, Textarea } from "@/components/ui/Input";
import { GuidancePanel } from "@/components/GuidancePanel";
import type { AiGuidance } from "@/types";

export default function NewFlowPage() {
  const router = useRouter();

  const [vision, setVision] = useState("");
  const [theme, setTheme] = useState("");
  const [triggerWord, setTriggerWord] = useState("");

  const [guidance, setGuidance] = useState<AiGuidance | null>(null);
  const [guidanceLoading, setGuidanceLoading] = useState(false);
  const [guidanceError, setGuidanceError] = useState("");

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");

  async function handleGetGuidance() {
    if (!vision.trim() || !theme.trim()) {
      setGuidanceError("Fill in vision and theme first.");
      return;
    }
    setGuidanceError("");
    setGuidanceLoading(true);
    try {
      const res = await fetch("/api/ai/guidance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vision: vision.trim(), theme: theme.trim() }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Failed to get guidance");
      setGuidance(json.guidance as AiGuidance);
      // Pre-fill trigger word from suggestion if not already set
      if (!triggerWord && json.guidance?.suggested_trigger_word) {
        setTriggerWord(json.guidance.suggested_trigger_word);
      }
    } catch (err) {
      setGuidanceError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setGuidanceLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError("");

    if (!vision.trim()) { setFormError("Vision is required."); return; }
    if (!theme.trim()) { setFormError("Theme is required."); return; }
    if (!triggerWord.trim()) { setFormError("Trigger word is required."); return; }

    setSubmitting(true);
    try {
      // 1. Create the flow
      const createRes = await fetch("/api/flows", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          vision: vision.trim(),
          theme: theme.trim(),
          trigger_word: triggerWord.trim(),
        }),
      });
      const createJson = await createRes.json();
      if (!createRes.ok) throw new Error(createJson.error ?? "Failed to create flow");

      const flowId: string = createJson.id;

      // 2. If we have guidance, persist it immediately
      if (guidance) {
        await fetch(`/api/flows/${flowId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ai_guidance: guidance }),
        });
      }

      // 3. Navigate to the upload step
      router.push(`/flows/${flowId}/upload`);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Something went wrong");
      setSubmitting(false);
    }
  }

  const canGetGuidance = vision.trim().length > 0 && theme.trim().length > 0;
  const canSubmit = vision.trim() && theme.trim() && triggerWord.trim();

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      {/* Page header */}
      <div className="mb-8">
        <h1
          className="text-2xl font-bold tracking-tight"
          style={{ color: "var(--color-text-primary)" }}
        >
          New LoRA Flow
        </h1>
        <p
          className="mt-1 text-sm"
          style={{ color: "var(--color-text-secondary)" }}
        >
          Define your vision and let AI guide the training process
        </p>
      </div>

      {/* Two-panel layout */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2 lg:items-start">
        {/* ---- Left panel: form ---- */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <FormCard>
            <SectionLabel step={1} label="Describe your LoRA" />

            <Textarea
              label="Vision"
              id="vision"
              rows={3}
              placeholder="e.g. Product LoRA for UGC campaign showcasing our skincare serum"
              value={vision}
              onChange={(e) => setVision(e.target.value)}
              hint="What is this LoRA for? How will it be used?"
            />

            <Textarea
              label="Theme"
              id="theme"
              rows={3}
              placeholder="e.g. Clean product shots of the Renew serum from multiple angles on white and marble backgrounds"
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
              hint="What should the images look like? What is the subject?"
            />

            {/* Get guidance button */}
            <div className="flex items-center gap-3">
              <Button
                type="button"
                variant="secondary"
                size="md"
                disabled={!canGetGuidance}
                loading={guidanceLoading}
                onClick={handleGetGuidance}
              >
                {guidanceLoading ? "Analyzing…" : "✦ Get AI Guidance"}
              </Button>
              {guidanceError && (
                <p className="text-xs" style={{ color: "#dc2626" }}>
                  {guidanceError}
                </p>
              )}
            </div>
          </FormCard>

          <FormCard>
            <SectionLabel step={2} label="Trigger word" />

            <Input
              label="Trigger word"
              id="trigger-word"
              placeholder="e.g. MYBRAND_serum"
              value={triggerWord}
              onChange={(e) => setTriggerWord(e.target.value)}
              hint="A unique token that activates your LoRA during generation. No spaces."
              style={{ fontFamily: "var(--font-mono)" }}
            />

            {guidance?.suggested_trigger_word &&
              triggerWord !== guidance.suggested_trigger_word && (
                <button
                  type="button"
                  className="self-start text-xs underline-offset-2 underline transition-opacity hover:opacity-70"
                  style={{ color: "var(--color-accent)" }}
                  onClick={() =>
                    setTriggerWord(guidance.suggested_trigger_word)
                  }
                >
                  Use AI suggestion:{" "}
                  <code style={{ fontFamily: "var(--font-mono)" }}>
                    {guidance.suggested_trigger_word}
                  </code>
                </button>
              )}
          </FormCard>

          {/* Form error + submit */}
          <div className="flex flex-col gap-3">
            {formError && (
              <p
                className="text-sm rounded-md px-3 py-2"
                style={{
                  color: "var(--color-status-failed-text)",
                  backgroundColor: "var(--color-status-failed-bg)",
                  border: "1px solid var(--color-status-failed-border)",
                }}
              >
                {formError}
              </p>
            )}
            <Button
              type="submit"
              size="lg"
              disabled={!canSubmit}
              loading={submitting}
              className="w-full sm:w-auto"
            >
              {submitting ? "Creating…" : "Create Flow & Upload Images →"}
            </Button>
          </div>
        </form>

        {/* ---- Right panel: guidance ---- */}
        <div className="lg:sticky lg:top-24">
          <GuidancePanel guidance={guidance} loading={guidanceLoading} />
        </div>
      </div>
    </div>
  );
}

// ---- Local helpers ---------------------------------------------------------

function FormCard({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="rounded-lg p-6 flex flex-col gap-4"
      style={{
        backgroundColor: "var(--color-surface)",
        border: "1px solid var(--color-border)",
      }}
    >
      {children}
    </div>
  );
}

function SectionLabel({ step, label }: { step: number; label: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <span
        className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white"
        style={{ backgroundColor: "var(--color-accent)" }}
      >
        {step}
      </span>
      <h2
        className="text-sm font-semibold"
        style={{ color: "var(--color-text-primary)" }}
      >
        {label}
      </h2>
    </div>
  );
}
