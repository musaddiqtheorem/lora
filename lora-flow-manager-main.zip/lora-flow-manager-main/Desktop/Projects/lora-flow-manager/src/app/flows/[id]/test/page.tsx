"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import Image from "next/image";
import { createClient } from "@/lib/supabase/client";
import { FlowStepper } from "@/components/FlowStepper";
import { Button } from "@/components/ui/Button";
import {
  FAL_GENERATION_MODELS,
  FAL_DEFAULT_GENERATION_MODEL,
  LORA_SCALE_MIN,
  LORA_SCALE_MAX,
  LORA_SCALE_DEFAULT,
} from "@/lib/constants";
import type { LoraFlow, LoraTest, GenerateTestResponse } from "@/types";

export default function TestPage() {
  const params = useParams<{ id: string }>();
  const flowId = params.id;
  const router = useRouter();
  const supabase = createClient();

  const [flow, setFlow] = useState<LoraFlow | null>(null);
  const [tests, setTests] = useState<LoraTest[]>([]);
  const [pageLoading, setPageLoading] = useState(true);

  // Generation form state
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState(FAL_DEFAULT_GENERATION_MODEL);
  const [loraScale, setLoraScale] = useState(LORA_SCALE_DEFAULT);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState("");
  const [latestResult, setLatestResult] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push("/login"); return; }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: flowData } = await (supabase as any)
        .from("lora_flows")
        .select("*")
        .eq("id", flowId)
        .single();

      if (!flowData) { router.push("/"); return; }
      setFlow(flowData as LoraFlow);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: testData } = await (supabase as any)
        .from("lora_tests")
        .select("*")
        .eq("flow_id", flowId)
        .order("created_at", { ascending: false });

      setTests((testData ?? []) as LoraTest[]);
      setPageLoading(false);
    }
    load();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flowId]);

  const triggerWord = flow?.trigger_word ?? "";

  const quickPrompts = [
    `a photo of ${triggerWord} in a studio setting, professional lighting`,
    `${triggerWord} outdoors, golden hour, cinematic`,
    `close-up portrait of ${triggerWord}, shallow depth of field`,
  ];

  async function handleGenerate() {
    if (!prompt.trim() || !flow) return;
    setGenError("");
    setGenerating(true);

    try {
      const res = await fetch("/api/test/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          flow_id: flowId,
          prompt: prompt.trim(),
          model,
          lora_scale: loraScale,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Generation failed");

      const result = json as GenerateTestResponse;
      setLatestResult(result.result_url);

      // Prepend to history
      const newTest: LoraTest = {
        id: result.test_id,
        flow_id: flowId,
        prompt: prompt.trim(),
        result_url: result.result_url,
        model_used: model,
        created_at: new Date().toISOString(),
      };
      setTests((prev) => [newTest, ...prev]);
    } catch (err) {
      setGenError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setGenerating(false);
    }
  }

  if (pageLoading) return <PageSkeleton />;
  if (!flow) return null;

  const canGenerate = prompt.trim().length > 0 && !!flow.lora_url;

  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      <FlowStepper flowId={flowId} currentStep={5} />

      <div>
        <h1 className="text-xl font-bold tracking-tight" style={{ color: "var(--color-text-primary)" }}>
          Test Playground
        </h1>
        <p className="mt-1 text-sm" style={{ color: "var(--color-text-secondary)" }}>
          Generate images using your trained LoRA.
        </p>
      </div>

      {!flow.lora_url && (
        <div
          className="rounded-lg px-4 py-3 text-sm"
          style={{
            backgroundColor: "var(--color-status-failed-bg)",
            border: "1px solid var(--color-status-failed-border)",
            color: "var(--color-status-failed-text)",
          }}
        >
          No LoRA URL found. Make sure training completed successfully before testing.
        </div>
      )}

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* Left: controls */}
        <div className="flex flex-col gap-5">
          {/* Trigger word reminder */}
          <div
            className="rounded-md px-3 py-2 text-xs flex items-center gap-2"
            style={{
              backgroundColor: "var(--color-accent-light)",
              border: "1px solid var(--color-border)",
            }}
          >
            <span style={{ color: "var(--color-text-muted)" }}>Trigger word:</span>
            <code
              className="font-semibold"
              style={{ fontFamily: "var(--font-mono)", color: "var(--color-accent)" }}
            >
              {triggerWord}
            </code>
          </div>

          {/* Prompt textarea */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
              Prompt
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              placeholder={`a photo of ${triggerWord}…`}
              className="w-full rounded-md px-3 py-2 text-sm resize-none outline-none transition-colors"
              style={{
                backgroundColor: "var(--color-background)",
                border: "1px solid var(--color-border-strong)",
                color: "var(--color-text-primary)",
                fontFamily: "inherit",
              }}
            />
          </div>

          {/* Quick prompts */}
          <div className="flex flex-col gap-1.5">
            <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--color-text-muted)" }}>
              Quick prompts
            </p>
            <div className="flex flex-col gap-1.5">
              {quickPrompts.map((qp, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setPrompt(qp)}
                  className="text-left text-xs rounded-md px-3 py-2 transition-colors hover:opacity-80"
                  style={{
                    backgroundColor: "var(--color-surface)",
                    border: "1px solid var(--color-border)",
                    color: "var(--color-text-secondary)",
                  }}
                >
                  {qp}
                </button>
              ))}
            </div>
          </div>

          {/* Model selector */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
              Model
            </label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="rounded-md px-3 py-2 text-sm outline-none"
              style={{
                backgroundColor: "var(--color-background)",
                border: "1px solid var(--color-border-strong)",
                color: "var(--color-text-primary)",
              }}
            >
              {FAL_GENERATION_MODELS.map((m) => (
                <option key={m.id} value={m.id}>{m.label}</option>
              ))}
            </select>
          </div>

          {/* LoRA scale slider */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
                LoRA Scale
              </label>
              <span
                className="text-sm font-semibold tabular-nums px-2 py-0.5 rounded"
                style={{ backgroundColor: "var(--color-accent-light)", color: "var(--color-accent)" }}
              >
                {loraScale.toFixed(2)}
              </span>
            </div>
            <input
              type="range"
              min={LORA_SCALE_MIN}
              max={LORA_SCALE_MAX}
              step={0.05}
              value={loraScale}
              onChange={(e) => setLoraScale(Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
            <div className="flex justify-between text-xs" style={{ color: "var(--color-text-muted)" }}>
              <span>{LORA_SCALE_MIN} (subtle)</span>
              <span>{LORA_SCALE_MAX} (strong)</span>
            </div>
          </div>

          {genError && (
            <p className="text-xs" style={{ color: "var(--color-status-failed-text)" }}>
              {genError}
            </p>
          )}

          <Button
            size="md"
            loading={generating}
            disabled={!canGenerate}
            onClick={handleGenerate}
          >
            {generating ? "Generating…" : "✦ Generate"}
          </Button>
        </div>

        {/* Right: result + history */}
        <div className="flex flex-col gap-5">
          {/* Latest result */}
          {latestResult ? (
            <div className="flex flex-col gap-2">
              <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--color-text-muted)" }}>
                Latest result
              </p>
              <div
                className="relative rounded-lg overflow-hidden aspect-square w-full"
                style={{ border: "1px solid var(--color-border)" }}
              >
                <Image
                  src={latestResult}
                  alt="Generated image"
                  fill
                  className="object-cover"
                  unoptimized
                />
              </div>
              <a
                href={latestResult}
                download
                target="_blank"
                rel="noopener noreferrer"
                className="self-end"
              >
                <Button variant="secondary" size="sm">
                  Download
                </Button>
              </a>
            </div>
          ) : (
            <div
              className="rounded-lg flex items-center justify-center aspect-square"
              style={{
                border: "1.5px dashed var(--color-border-strong)",
                backgroundColor: "var(--color-surface)",
              }}
            >
              <p className="text-sm" style={{ color: "var(--color-text-muted)" }}>
                Your generated image will appear here
              </p>
            </div>
          )}

          {/* Test history */}
          {tests.length > 0 && (
            <div className="flex flex-col gap-2">
              <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--color-text-muted)" }}>
                History
              </p>
              <div className="flex flex-col gap-2 max-h-80 overflow-y-auto pr-1">
                {tests.map((test) => (
                  <TestHistoryRow key={test.id} test={test} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---- Sub-components --------------------------------------------------------

function TestHistoryRow({ test }: { test: LoraTest }) {
  return (
    <div
      className="flex items-center gap-3 rounded-md px-3 py-2"
      style={{
        backgroundColor: "var(--color-surface)",
        border: "1px solid var(--color-border)",
      }}
    >
      {/* Thumbnail */}
      <div
        className="relative h-10 w-10 shrink-0 rounded overflow-hidden"
        style={{ backgroundColor: "var(--color-background)" }}
      >
        <Image
          src={test.result_url}
          alt=""
          fill
          className="object-cover"
          unoptimized
        />
      </div>

      <div className="flex-1 min-w-0">
        <p
          className="text-xs truncate"
          style={{ color: "var(--color-text-primary)" }}
          title={test.prompt}
        >
          {test.prompt}
        </p>
        <p className="text-xs" style={{ color: "var(--color-text-muted)" }}>
          {new Date(test.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </p>
      </div>

      <a href={test.result_url} target="_blank" rel="noopener noreferrer" download>
        <button
          type="button"
          className="text-xs underline underline-offset-2 transition-opacity hover:opacity-70 shrink-0"
          style={{ color: "var(--color-text-secondary)" }}
        >
          View
        </button>
      </a>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      <div className="h-8 rounded animate-pulse w-full" style={{ backgroundColor: "var(--color-border)" }} />
      <div className="h-6 rounded animate-pulse w-1/2" style={{ backgroundColor: "var(--color-border)" }} />
      <div className="grid grid-cols-2 gap-8">
        <div className="h-80 rounded-lg animate-pulse" style={{ backgroundColor: "var(--color-border)" }} />
        <div className="h-80 rounded-lg animate-pulse" style={{ backgroundColor: "var(--color-border)" }} />
      </div>
    </div>
  );
}
