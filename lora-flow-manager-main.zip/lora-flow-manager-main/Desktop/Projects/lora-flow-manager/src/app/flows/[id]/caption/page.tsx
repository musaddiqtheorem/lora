"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { FlowStepper } from "@/components/FlowStepper";
import { CaptionGrid } from "@/components/CaptionGrid";
import { Button } from "@/components/ui/Button";
import type { LoraFlow, FlowImage, CaptionResult } from "@/types";

export default function CaptionPage() {
  const params = useParams<{ id: string }>();
  const flowId = params.id;
  const router = useRouter();
  const supabase = createClient();

  const [flow, setFlow] = useState<LoraFlow | null>(null);
  const [images, setImages] = useState<FlowImage[]>([]);
  const [loadingIds, setLoadingIds] = useState<Set<string>>(new Set());
  const [pageLoading, setPageLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push("/login"); return; }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: flowData } = await (supabase as any)
        .from("lora_flows")
        .select("*")
        .eq("id", flowId)
        .single();

      if (!flowData) { router.push("/"); return; }
      setFlow(flowData as LoraFlow);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: imgData } = await (supabase as any)
        .from("flow_images")
        .select("*")
        .eq("flow_id", flowId)
        .order("sort_order", { ascending: true });

      setImages((imgData ?? []) as FlowImage[]);
      setPageLoading(false);
    }
    load();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flowId]);

  // Optimistic local caption update + debounced DB persist
  const handleCaptionChange = useCallback(
    async (imageId: string, caption: string) => {
      setImages((prev) =>
        prev.map((img) => (img.id === imageId ? { ...img, caption } : img))
      );
      // Persist immediately (no debounce needed — textarea fires on change,
      // and Supabase calls are cheap; add debounce if needed later)
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (supabase as any)
        .from("flow_images")
        .update({ caption })
        .eq("id", imageId);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  async function handleGenerateCaptions() {
    if (!flow) return;
    setGenError("");
    setGenerating(true);

    // Mark all images as loading
    const allIds = new Set(images.map((img) => img.id));
    setLoadingIds(allIds);

    try {
      const res = await fetch("/api/ai/captions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          flow_id: flowId,
          trigger_word: flow.trigger_word,
          theme: flow.theme,
          images: images.map((img) => ({
            id: img.id,
            public_url: img.public_url,
          })),
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Caption generation failed");

      const captions = json.captions as CaptionResult[];

      // Apply returned captions to local state
      setImages((prev) =>
        prev.map((img) => {
          const match = captions.find((c) => c.image_id === img.id);
          if (!match) return img;
          return {
            ...img,
            caption: match.caption,
            ai_draft_caption: match.caption,
          };
        })
      );
    } catch (err) {
      setGenError(
        err instanceof Error ? err.message : "Something went wrong"
      );
    } finally {
      setGenerating(false);
      setLoadingIds(new Set());
    }
  }

  async function handleReadyForTraining() {
    setSubmitting(true);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any)
      .from("lora_flows")
      .update({ status: "ready", updated_at: new Date().toISOString() })
      .eq("id", flowId);
    router.push(`/flows/${flowId}/train`);
  }

  if (pageLoading) return <PageSkeleton />;
  if (!flow) return null;

  const triggerWord = flow.trigger_word;
  const captionedCount = images.filter((img) => img.caption.trim().length > 0).length;
  const allHaveTrigger = images.every(
    (img) =>
      img.caption.trim().length > 0 &&
      img.caption.toLowerCase().includes(triggerWord.toLowerCase())
  );
  const allCaptioned = captionedCount === images.length && images.length > 0;
  const canProceed = allCaptioned && allHaveTrigger;
  const missingTriggerCount = images.filter(
    (img) =>
      img.caption.trim().length > 0 &&
      !img.caption.toLowerCase().includes(triggerWord.toLowerCase())
  ).length;

  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      {/* Stepper */}
      <FlowStepper flowId={flowId} currentStep={3} />

      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div>
          <h1
            className="text-xl font-bold tracking-tight"
            style={{ color: "var(--color-text-primary)" }}
          >
            Caption Images
          </h1>
          <p
            className="mt-1 text-sm"
            style={{ color: "var(--color-text-secondary)" }}
          >
            Every caption must include your trigger word:{" "}
            <code
              className="rounded px-1 py-0.5 text-xs"
              style={{
                fontFamily: "var(--font-mono)",
                backgroundColor: "var(--color-accent-light)",
                color: "var(--color-accent)",
              }}
            >
              {triggerWord || "—"}
            </code>
          </p>
        </div>

        {/* Generate captions button */}
        <div className="flex flex-col items-end gap-1.5 shrink-0">
          <Button
            variant="secondary"
            size="md"
            loading={generating}
            disabled={images.length === 0}
            onClick={handleGenerateCaptions}
          >
            {generating ? "Generating…" : "✦ Generate AI Captions"}
          </Button>
          {genError && (
            <p className="text-xs" style={{ color: "var(--color-status-failed-text)" }}>
              {genError}
            </p>
          )}
        </div>
      </div>

      {/* Caption grid */}
      <CaptionGrid
        images={images}
        triggerWord={triggerWord}
        loadingIds={generating ? loadingIds : new Set()}
        onCaptionChange={handleCaptionChange}
      />

      {/* Summary stats bar */}
      <div
        className="rounded-lg px-4 py-3 flex flex-wrap items-center gap-x-6 gap-y-2"
        style={{
          backgroundColor: "var(--color-surface)",
          border: "1px solid var(--color-border)",
        }}
      >
        <Stat
          label="Captioned"
          value={`${captionedCount} / ${images.length}`}
          ok={allCaptioned}
        />
        <Stat
          label="Trigger word present"
          value={
            missingTriggerCount === 0
              ? `All ${captionedCount}`
              : `${captionedCount - missingTriggerCount} / ${captionedCount}`
          }
          ok={allHaveTrigger && captionedCount > 0}
        />
        {canProceed && (
          <span
            className="ml-auto text-xs font-medium"
            style={{ color: "var(--color-status-ready-text)" }}
          >
            ✓ All captions look good
          </span>
        )}
      </div>

      {/* Footer actions */}
      <div className="flex items-center justify-between">
        <Button
          variant="ghost"
          size="md"
          onClick={() => router.push(`/flows/${flowId}/upload`)}
        >
          ← Back to Upload
        </Button>
        <div className="flex items-center gap-3">
          {!canProceed && images.length > 0 && (
            <p
              className="text-xs max-w-xs text-right"
              style={{ color: "var(--color-text-muted)" }}
            >
              {!allCaptioned
                ? `${images.length - captionedCount} image${images.length - captionedCount === 1 ? "" : "s"} still need captions`
                : `${missingTriggerCount} caption${missingTriggerCount === 1 ? "" : "s"} missing trigger word`}
            </p>
          )}
          <Button
            size="md"
            disabled={!canProceed}
            loading={submitting}
            onClick={handleReadyForTraining}
          >
            Ready for Training →
          </Button>
        </div>
      </div>
    </div>
  );
}

// ---- Local helpers ---------------------------------------------------------

function Stat({
  label,
  value,
  ok,
}: {
  label: string;
  value: string;
  ok: boolean;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <span
        className="text-xs"
        style={{ color: "var(--color-text-muted)" }}
      >
        {label}:
      </span>
      <span
        className="text-xs font-semibold tabular-nums"
        style={{
          color: ok
            ? "var(--color-status-ready-text)"
            : "var(--color-text-primary)",
        }}
      >
        {value}
      </span>
      {ok && (
        <svg className="h-3.5 w-3.5" viewBox="0 0 14 14" fill="none" aria-hidden>
          <circle cx="7" cy="7" r="7" fill="var(--color-status-ready-bg)" />
          <path
            d="M4 7l2 2 4-4"
            stroke="var(--color-status-ready-text)"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      <div className="h-8 rounded animate-pulse w-full" style={{ backgroundColor: "var(--color-border)" }} />
      <div className="h-6 rounded animate-pulse w-1/2" style={{ backgroundColor: "var(--color-border)" }} />
      {[1, 2, 3].map((i) => (
        <div key={i} className="h-36 rounded-lg animate-pulse" style={{ backgroundColor: "var(--color-border)" }} />
      ))}
    </div>
  );
}
