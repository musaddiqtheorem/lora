"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { FlowStepper } from "@/components/FlowStepper";
import { ImageUploader } from "@/components/ImageUploader";
import { Button } from "@/components/ui/Button";
import { MIN_IMAGES_TO_PROCEED } from "@/lib/constants";
import type { LoraFlow, FlowImage, AiGuidance } from "@/types";

export default function UploadPage() {
  const params = useParams<{ id: string }>();
  const flowId = params.id;
  const router = useRouter();
  const supabase = createClient();

  const [flow, setFlow] = useState<LoraFlow | null>(null);
  const [images, setImages] = useState<FlowImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [guidanceOpen, setGuidanceOpen] = useState(false);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push("/login"); return; }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: flowData } = await (supabase as any)
        .from("lora_flows")
        .select("*")
        .eq("id", flowId)
        .single();

      if (!flowData) { router.push("/"); return; }
      setFlow(flowData as LoraFlow);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: imgData } = await (supabase as any)
        .from("flow_images")
        .select("*")
        .eq("flow_id", flowId)
        .order("sort_order", { ascending: true });

      setImages((imgData ?? []) as FlowImage[]);
      setLoading(false);
    }
    load();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flowId]);

  async function handleContinue() {
    setSubmitting(true);
    // Mark flow as captioning
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any)
      .from("lora_flows")
      .update({ status: "captioning", updated_at: new Date().toISOString() })
      .eq("id", flowId);
    router.push(`/flows/${flowId}/caption`);
  }

  if (loading) return <PageSkeleton />;
  if (!flow) return null;

  const guidance = flow.ai_guidance as AiGuidance | null;
  const recommended = guidance?.recommended_image_count ?? null;
  const count = images.length;
  const canContinue = count >= MIN_IMAGES_TO_PROCEED;

  // Get the authenticated user id (stored on flow)
  const userId = flow.user_id;

  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      {/* Stepper */}
      <FlowStepper flowId={flowId} currentStep={2} />

      {/* Page header */}
      <div>
        <h1
          className="text-xl font-bold tracking-tight"
          style={{ color: "var(--color-text-primary)" }}
        >
          Upload Training Images
        </h1>
        <p
          className="mt-1 text-sm"
          style={{ color: "var(--color-text-secondary)" }}
        >
          For{" "}
          <code
            className="rounded px-1 py-0.5 text-xs"
            style={{
              fontFamily: "var(--font-mono)",
              backgroundColor: "var(--color-accent-light)",
              color: "var(--color-accent)",
            }}
          >
            {flow.trigger_word || "—"}
          </code>
          {" "}— {flow.theme}
        </p>
      </div>

      {/* Guidance summary (collapsible) */}
      {guidance && (
        <div
          className="rounded-lg overflow-hidden"
          style={{ border: "1px solid var(--color-border)" }}
        >
          <button
            type="button"
            onClick={() => setGuidanceOpen((o) => !o)}
            className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium transition-colors text-left"
            style={{
              backgroundColor: "var(--color-surface)",
              color: "var(--color-text-primary)",
            }}
          >
            <span className="flex items-center gap-2">
              <span
                className="flex h-5 w-5 items-center justify-center rounded text-xs font-bold text-white"
                style={{ backgroundColor: "var(--color-accent)" }}
              >
                ✦
              </span>
              AI Guidance Summary
            </span>
            <ChevronIcon open={guidanceOpen} />
          </button>
          {guidanceOpen && (
            <div
              className="px-4 pb-4 flex flex-col gap-3"
              style={{ borderTop: "1px solid var(--color-border)" }}
            >
              <div className="flex items-center gap-6 pt-3">
                <Stat
                  label="Recommended"
                  value={`${guidance.recommended_image_count} images`}
                />
                <Stat
                  label="Training steps"
                  value={guidance.estimated_training_steps.toLocaleString()}
                />
              </div>
              <div>
                <p
                  className="text-xs font-semibold uppercase tracking-wide mb-1.5"
                  style={{ color: "var(--color-text-muted)" }}
                >
                  Shot types to include
                </p>
                <ul className="flex flex-wrap gap-1.5">
                  {guidance.shot_types.map((shot, i) => (
                    <li
                      key={i}
                      className="rounded-full px-2.5 py-0.5 text-xs"
                      style={{
                        backgroundColor: "var(--color-background)",
                        border: "1px solid var(--color-border-strong)",
                        color: "var(--color-text-secondary)",
                      }}
                    >
                      {shot}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Image count progress */}
      <ImageCountBar
        count={count}
        recommended={recommended}
        min={MIN_IMAGES_TO_PROCEED}
      />

      {/* Uploader */}
      <ImageUploader
        flowId={flowId}
        userId={userId}
        existingImages={images}
        onImagesChange={setImages}
      />

      {/* Footer actions */}
      <div className="flex items-center justify-between pt-2">
        <Button
          variant="ghost"
          size="md"
          onClick={() => router.push(`/flows/${flowId}`)}
        >
          ← Back
        </Button>
        <div className="flex items-center gap-3">
          {!canContinue && (
            <p
              className="text-xs"
              style={{ color: "var(--color-text-muted)" }}
            >
              Need at least {MIN_IMAGES_TO_PROCEED} images (
              {Math.max(0, MIN_IMAGES_TO_PROCEED - count)} more)
            </p>
          )}
          <Button
            size="md"
            disabled={!canContinue}
            loading={submitting}
            onClick={handleContinue}
          >
            Continue to Captioning →
          </Button>
        </div>
      </div>
    </div>
  );
}

// ---- Local helpers ---------------------------------------------------------

function ImageCountBar({
  count,
  recommended,
  min,
}: {
  count: number;
  recommended: number | null;
  min: number;
}) {
  const target = recommended ?? min;
  const pct = Math.min(100, Math.round((count / target) * 100));
  const atMin = count >= min;

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between text-sm">
        <span style={{ color: "var(--color-text-secondary)" }}>
          <span
            className="font-semibold tabular-nums"
            style={{ color: atMin ? "var(--color-status-ready-text)" : "var(--color-text-primary)" }}
          >
            {count}
          </span>
          {recommended ? ` / ${recommended} recommended` : ` / ${min} minimum`}
          {" images"}
        </span>
        {atMin && (
          <span
            className="text-xs font-medium"
            style={{ color: "var(--color-status-ready-text)" }}
          >
            ✓ Ready to continue
          </span>
        )}
      </div>
      <div
        className="h-1.5 rounded-full overflow-hidden"
        style={{ backgroundColor: "var(--color-border)" }}
      >
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${pct}%`,
            backgroundColor: atMin
              ? "var(--color-status-ready-text)"
              : "var(--color-accent)",
          }}
        />
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs" style={{ color: "var(--color-text-muted)" }}>
        {label}
      </p>
      <p className="text-sm font-semibold" style={{ color: "var(--color-text-primary)" }}>
        {value}
      </p>
    </div>
  );
}

function ChevronIcon({ open }: { open: boolean }) {
  return (
    <svg
      className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`}
      viewBox="0 0 16 16"
      fill="none"
      aria-hidden
      style={{ color: "var(--color-text-muted)" }}
    >
      <path
        d="M4 6l4 4 4-4"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function PageSkeleton() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-10 flex flex-col gap-8">
      <div className="h-8 rounded animate-pulse" style={{ backgroundColor: "var(--color-border)", width: "100%" }} />
      <div className="h-6 rounded animate-pulse w-1/2" style={{ backgroundColor: "var(--color-border)" }} />
      <div className="h-40 rounded-xl animate-pulse" style={{ backgroundColor: "var(--color-border)" }} />
    </div>
  );
}
