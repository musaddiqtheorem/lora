"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

type Mode = "sign_in" | "sign_up";

export function LoginForm() {
  const router = useRouter();
  const supabase = createClient();

  const [mode, setMode] = useState<Mode>("sign_in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSuccessMsg("");
    setLoading(true);

    try {
      if (mode === "sign_in") {
        const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
        if (authError) throw authError;
        router.push("/");
        router.refresh();
      } else {
        const { error: authError } = await supabase.auth.signUp({ email, password });
        if (authError) throw authError;
        setSuccessMsg("Check your email to confirm your account, then sign in.");
        setMode("sign_in");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ backgroundColor: "var(--color-background)" }}>
      <div
        className="w-full max-w-sm rounded-xl px-8 py-8 flex flex-col gap-6"
        style={{
          backgroundColor: "var(--color-surface)",
          border: "1px solid var(--color-border)",
        }}
      >
        {/* Header */}
        <div className="text-center flex flex-col gap-1">
          <div
            className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-lg text-white text-lg font-bold"
            style={{ backgroundColor: "var(--color-accent)" }}
          >
            L
          </div>
          <h1 className="text-lg font-bold tracking-tight" style={{ color: "var(--color-text-primary)" }}>
            {mode === "sign_in" ? "Sign in to LoRA Flow" : "Create your account"}
          </h1>
          <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
            {mode === "sign_in"
              ? "Welcome back."
              : "Start building LoRA models in minutes."}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Input
            label="Email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Input
            label="Password"
            type="password"
            autoComplete={mode === "sign_in" ? "current-password" : "new-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            hint={mode === "sign_up" ? "At least 8 characters" : undefined}
          />

          {error && (
            <p className="text-xs" style={{ color: "var(--color-status-failed-text)" }}>
              {error}
            </p>
          )}
          {successMsg && (
            <p className="text-xs" style={{ color: "var(--color-status-ready-text)" }}>
              {successMsg}
            </p>
          )}

          <Button size="md" loading={loading} disabled={!email || !password}>
            {mode === "sign_in" ? "Sign In" : "Create Account"}
          </Button>
        </form>

        {/* Toggle mode */}
        <p className="text-center text-sm" style={{ color: "var(--color-text-secondary)" }}>
          {mode === "sign_in" ? "Don't have an account?" : "Already have an account?"}{" "}
          <button
            type="button"
            onClick={() => { setMode(mode === "sign_in" ? "sign_up" : "sign_in"); setError(""); setSuccessMsg(""); }}
            className="font-medium underline underline-offset-2 transition-opacity hover:opacity-70"
            style={{ color: "var(--color-accent)" }}
          >
            {mode === "sign_in" ? "Sign up" : "Sign in"}
          </button>
        </p>
      </div>
    </div>
  );
}
