import type { Metadata } from "next";
import { DM_Sans, JetBrains_Mono } from "next/font/google";
import Link from "next/link";
import "./globals.css";

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "LoRA Flow Manager",
  description: "End-to-end LoRA training workflow on fal.ai",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${dmSans.variable} ${jetbrainsMono.variable}`}>
      <body>
        <div className="min-h-dvh flex flex-col">
          <TopNav />
          <main className="flex-1">{children}</main>
        </div>
      </body>
    </html>
  );
}

function TopNav() {
  return (
    <header
      style={{
        backgroundColor: "var(--color-surface)",
        borderBottom: "1px solid var(--color-border)",
      }}
    >
      <div className="mx-auto max-w-7xl px-6 h-14 flex items-center justify-between">
        {/* Logo / wordmark */}
        <Link
          href="/"
          className="flex items-center gap-2.5"
          style={{ textDecoration: "none" }}
        >
          <span
            className="flex h-7 w-7 items-center justify-center rounded-md text-white text-xs font-bold select-none"
            style={{ backgroundColor: "var(--color-accent)" }}
            aria-hidden
          >
            L
          </span>
          <span
            className="text-sm font-semibold tracking-tight"
            style={{ color: "var(--color-text-primary)" }}
          >
            LoRA Flow
          </span>
        </Link>

        {/* Nav actions */}
        <nav className="flex items-center gap-4">
          <Link
            href="/"
            className="text-sm transition-colors"
            style={{ color: "var(--color-text-secondary)" }}
          >
            Dashboard
          </Link>
          <Link
            href="/flows/new"
            className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-white transition-colors"
            style={{ backgroundColor: "var(--color-accent)" }}
          >
            <span aria-hidden>+</span>
            New Flow
          </Link>
        </nav>
      </div>
    </header>
  );
}
