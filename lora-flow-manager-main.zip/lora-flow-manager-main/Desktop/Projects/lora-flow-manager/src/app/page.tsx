import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { FlowCard } from "@/components/FlowCard";
import { Button } from "@/components/ui/Button";
import type { LoraFlow } from "@/types";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    // Redirect to login — middleware also handles this, but belt-and-suspenders
    const { redirect } = await import("next/navigation");
    redirect("/login");
  }

  // Fetch flows with image counts in a single query using a join
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flows } = await (supabase as any)
    .from("lora_flows")
    .select("*")
    .order("created_at", { ascending: false });

  const typedFlows = (flows ?? []) as LoraFlow[];

  // Fetch image counts for all flows in one query
  let imageCounts: Record<string, number> = {};
  if (typedFlows.length > 0) {
    const flowIds = typedFlows.map((f) => f.id);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: countRows } = await (supabase as any)
      .from("flow_images")
      .select("flow_id")
      .in("flow_id", flowIds);

    if (countRows) {
      imageCounts = (countRows as { flow_id: string }[]).reduce(
        (acc, row) => {
          acc[row.flow_id] = (acc[row.flow_id] ?? 0) + 1;
          return acc;
        },
        {} as Record<string, number>
      );
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-6 py-10">
      {/* Page header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1
            className="text-2xl font-bold tracking-tight"
            style={{ color: "var(--color-text-primary)" }}
          >
            LoRA Flows
          </h1>
          <p
            className="mt-1 text-sm"
            style={{ color: "var(--color-text-secondary)" }}
          >
            {typedFlows.length === 0
              ? "No flows yet. Create your first one."
              : `${typedFlows.length} flow${typedFlows.length === 1 ? "" : "s"}`}
          </p>
        </div>
        <Link href="/flows/new">
          <Button size="md">
            <span aria-hidden>+</span>
            New LoRA Flow
          </Button>
        </Link>
      </div>

      {/* Empty state */}
      {typedFlows.length === 0 && (
        <EmptyState />
      )}

      {/* Flow grid */}
      {typedFlows.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {typedFlows.map((flow) => (
            <FlowCard
              key={flow.id}
              flow={flow}
              imageCount={imageCounts[flow.id] ?? 0}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyState() {
  return (
    <div
      className="rounded-xl py-20 flex flex-col items-center gap-5 text-center"
      style={{
        border: "1.5px dashed var(--color-border-strong)",
      }}
    >
      {/* Icon */}
      <div
        className="flex h-14 w-14 items-center justify-center rounded-xl"
        style={{ backgroundColor: "var(--color-accent-light)" }}
      >
        <svg
          className="h-7 w-7"
          viewBox="0 0 28 28"
          fill="none"
          aria-hidden
        >
          <rect
            x="3" y="3" width="9" height="9" rx="2"
            stroke="var(--color-accent)" strokeWidth="1.5"
          />
          <rect
            x="16" y="3" width="9" height="9" rx="2"
            stroke="var(--color-accent)" strokeWidth="1.5"
          />
          <rect
            x="3" y="16" width="9" height="9" rx="2"
            stroke="var(--color-accent)" strokeWidth="1.5"
          />
          <path
            d="M20.5 16v9M16 20.5h9"
            stroke="var(--color-accent)" strokeWidth="1.5" strokeLinecap="round"
          />
        </svg>
      </div>

      <div>
        <p
          className="text-base font-semibold"
          style={{ color: "var(--color-text-primary)" }}
        >
          No LoRA flows yet
        </p>
        <p
          className="mt-1 text-sm max-w-xs"
          style={{ color: "var(--color-text-secondary)" }}
        >
          Create your first flow to start training a custom LoRA model on fal.ai
        </p>
      </div>

      <Link href="/flows/new">
        <Button size="md">
          <span aria-hidden>+</span>
          New LoRA Flow
        </Button>
      </Link>
    </div>
  );
}
