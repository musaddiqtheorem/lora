import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import type { UpdateFlowRequest } from "@/types";

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function GET(_request: Request, { params }: RouteContext) {
  const { id } = await params;
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error } = await (supabase as any)
    .from("lora_flows")
    .select("*")
    .eq("id", id)
    .single();

  if (error || !flow) {
    return NextResponse.json({ error: "Flow not found" }, { status: 404 });
  }

  return NextResponse.json(flow);
}

export async function PATCH(request: Request, { params }: RouteContext) {
  const { id } = await params;
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: UpdateFlowRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (Object.keys(body).length === 0) {
    return NextResponse.json({ error: "No fields to update" }, { status: 400 });
  }

  const {
    vision,
    theme,
    trigger_word,
    status,
    ai_guidance,
    training_config,
    fal_job_id,
    lora_url,
    training_started_at,
    training_completed_at,
    estimated_duration_sec,
    error_message,
  } = body;

  const patch: Record<string, unknown> = {
    updated_at: new Date().toISOString(),
  };

  if (vision !== undefined) patch.vision = vision.trim();
  if (theme !== undefined) patch.theme = theme.trim();
  if (trigger_word !== undefined) patch.trigger_word = trigger_word.trim();
  if (status !== undefined) patch.status = status;
  if (ai_guidance !== undefined) patch.ai_guidance = ai_guidance;
  if (training_config !== undefined) patch.training_config = training_config;
  if (fal_job_id !== undefined) patch.fal_job_id = fal_job_id;
  if (lora_url !== undefined) patch.lora_url = lora_url;
  if (training_started_at !== undefined) patch.training_started_at = training_started_at;
  if (training_completed_at !== undefined) patch.training_completed_at = training_completed_at;
  if (estimated_duration_sec !== undefined) patch.estimated_duration_sec = estimated_duration_sec;
  if (error_message !== undefined) patch.error_message = error_message;

  // RLS ensures users can only update their own flows
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error } = await (supabase as any)
    .from("lora_flows")
    .update(patch)
    .eq("id", id)
    .select()
    .single();

  if (error) {
    console.error("[PATCH /api/flows/:id]", error);
    return NextResponse.json(
      { error: "Failed to update flow" },
      { status: 500 }
    );
  }

  if (!flow) {
    return NextResponse.json({ error: "Flow not found" }, { status: 404 });
  }

  return NextResponse.json(flow);
}

export async function DELETE(_request: Request, { params }: RouteContext) {
  const { id } = await params;
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Cascading delete on flow_images is handled by the DB (ON DELETE CASCADE).
  // RLS ensures only the owner can delete.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { error } = await (supabase as any)
    .from("lora_flows")
    .delete()
    .eq("id", id);

  if (error) {
    console.error("[DELETE /api/flows/:id]", error);
    return NextResponse.json(
      { error: "Failed to delete flow" },
      { status: 500 }
    );
  }

  return new NextResponse(null, { status: 204 });
}
