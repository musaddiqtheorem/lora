import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { DEFAULT_TRAINING_CONFIG } from "@/lib/constants";
import type { CreateFlowRequest } from "@/types";

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: CreateFlowRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { vision, theme, trigger_word } = body;

  if (!vision?.trim() || !theme?.trim()) {
    return NextResponse.json(
      { error: "vision and theme are required" },
      { status: 400 }
    );
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error } = await (supabase as any)
    .from("lora_flows")
    .insert({
      user_id: user.id,
      vision: vision.trim(),
      theme: theme.trim(),
      trigger_word: trigger_word?.trim() ?? "",
      status: "draft",
      ai_guidance: null,
      training_config: DEFAULT_TRAINING_CONFIG,
      fal_job_id: null,
      lora_url: null,
      training_started_at: null,
      training_completed_at: null,
      estimated_duration_sec: null,
      error_message: null,
    })
    .select()
    .single();

  if (error) {
    console.error("[POST /api/flows]", error);
    return NextResponse.json(
      { error: "Failed to create flow" },
      { status: 500 }
    );
  }

  return NextResponse.json(flow, { status: 201 });
}
