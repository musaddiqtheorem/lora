import { NextResponse } from "next/server";
import { createServiceClient } from "@/lib/supabase/server";
import type { WebHookResponse } from "@fal-ai/client";

interface TrainerPayload {
  diffusers_lora_file?: { url: string };
  config_file?: { url: string };
}

export async function POST(request: Request) {
  // Use the service-role client — this endpoint is called by fal.ai,
  // not by an authenticated browser session, so cookie-based auth won't work.
  const supabase = createServiceClient();

  let body: WebHookResponse<TrainerPayload>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { request_id, status, payload } = body;

  if (!request_id) {
    return NextResponse.json({ error: "Missing request_id" }, { status: 400 });
  }

  // Look up the flow by fal_job_id
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error: flowError } = await (supabase as any)
    .from("lora_flows")
    .select("id, status")
    .eq("fal_job_id", request_id)
    .single();

  if (flowError || !flow) {
    // Log but return 200 so fal.ai doesn't retry endlessly
    console.error(
      `[POST /api/training/webhook] No flow for request_id ${request_id}`,
      flowError
    );
    return NextResponse.json({ received: true });
  }

  const now = new Date().toISOString();

  if (status === "OK" && payload?.diffusers_lora_file?.url) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any)
      .from("lora_flows")
      .update({
        status: "complete",
        lora_url: payload.diffusers_lora_file.url,
        training_completed_at: now,
        error_message: null,
        updated_at: now,
      })
      .eq("id", flow.id);
  } else {
    const errorMessage =
      status === "ERROR"
        ? // fal sends the error as a string on the top-level `error` field
          (body as unknown as { error?: string }).error ?? "Training failed"
        : "Training completed without a LoRA file URL";

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any)
      .from("lora_flows")
      .update({
        status: "failed",
        error_message: errorMessage,
        training_completed_at: now,
        updated_at: now,
      })
      .eq("id", flow.id);
  }

  // Always return 200 — fal.ai will retry on non-2xx
  return NextResponse.json({ received: true });
}
