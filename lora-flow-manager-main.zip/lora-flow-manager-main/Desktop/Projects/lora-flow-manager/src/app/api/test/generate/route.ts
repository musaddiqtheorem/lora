import { NextResponse } from "next/server";
import { fal } from "@fal-ai/client";
import { createClient } from "@/lib/supabase/server";
import {
  FAL_DEFAULT_GENERATION_MODEL,
  LORA_SCALE_DEFAULT,
} from "@/lib/constants";
import type { GenerateTestRequest, GenerateTestResponse, LoraFlow } from "@/types";

fal.config({ credentials: process.env.FAL_KEY });

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: GenerateTestRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const {
    flow_id,
    prompt,
    model = FAL_DEFAULT_GENERATION_MODEL,
    lora_scale = LORA_SCALE_DEFAULT,
  } = body;

  if (!flow_id || !prompt?.trim()) {
    return NextResponse.json(
      { error: "flow_id and prompt are required" },
      { status: 400 }
    );
  }

  // Fetch flow — RLS ensures ownership
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error: flowError } = await (supabase as any)
    .from("lora_flows")
    .select("id, status, lora_url, trigger_word")
    .eq("id", flow_id)
    .single();

  if (flowError || !flow) {
    return NextResponse.json({ error: "Flow not found" }, { status: 404 });
  }

  const typedFlow = flow as Pick<LoraFlow, "id" | "status" | "lora_url" | "trigger_word">;

  if (typedFlow.status !== "complete" || !typedFlow.lora_url) {
    return NextResponse.json(
      { error: "Flow training is not complete or LoRA URL is missing" },
      { status: 400 }
    );
  }

  // Generate image with the trained LoRA
  let result;
  try {
    result = await fal.subscribe(model, {
      input: {
        prompt: prompt.trim(),
        loras: [
          {
            path: typedFlow.lora_url,
            scale: lora_scale,
          },
        ],
        image_size: "landscape_16_9",
        num_inference_steps: 28,
        guidance_scale: 3.5,
        num_images: 1,
        enable_safety_checker: false,
      },
    });
  } catch (err) {
    console.error("[POST /api/test/generate] fal.ai generation error:", err);
    return NextResponse.json(
      { error: "Failed to generate image" },
      { status: 502 }
    );
  }

  // fal returns data.images[0].url for image generation endpoints
  const generatedUrl =
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (result?.data as any)?.images?.[0]?.url as string | undefined;

  if (!generatedUrl) {
    console.error("[POST /api/test/generate] No image URL in response:", result);
    return NextResponse.json(
      { error: "No image returned from generation" },
      { status: 502 }
    );
  }

  // Persist the test result
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: testRecord, error: insertError } = await (supabase as any)
    .from("lora_tests")
    .insert({
      flow_id,
      prompt: prompt.trim(),
      result_url: generatedUrl,
      model_used: model,
    })
    .select()
    .single();

  if (insertError) {
    console.error("[POST /api/test/generate] Failed to save test:", insertError);
    // Still return the result — the generation succeeded even if logging fails
  }

  const response: GenerateTestResponse = {
    result_url: generatedUrl,
    test_id: testRecord?.id ?? "",
  };

  return NextResponse.json(response);
}
