import { NextResponse } from "next/server";
import { fal } from "@fal-ai/client";
import { createClient } from "@/lib/supabase/server";
import { FAL_TRAINER_MODEL, estimateTrainingTime } from "@/lib/constants";
import type { StartTrainingRequest, LoraFlow, FlowImage } from "@/types";

fal.config({ credentials: process.env.FAL_KEY });

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: StartTrainingRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { flow_id } = body;
  if (!flow_id) {
    return NextResponse.json({ error: "flow_id is required" }, { status: 400 });
  }

  // Fetch flow (RLS ensures ownership)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error: flowError } = await (supabase as any)
    .from("lora_flows")
    .select("*")
    .eq("id", flow_id)
    .single();

  if (flowError || !flow) {
    return NextResponse.json({ error: "Flow not found" }, { status: 404 });
  }

  const typedFlow = flow as LoraFlow;

  if (typedFlow.status === "training") {
    return NextResponse.json(
      { error: "Training already in progress" },
      { status: 409 }
    );
  }

  if (typedFlow.status === "complete") {
    return NextResponse.json(
      { error: "Training already complete" },
      { status: 409 }
    );
  }

  // Fetch all images for this flow
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: images, error: imagesError } = await (supabase as any)
    .from("flow_images")
    .select("*")
    .eq("flow_id", flow_id)
    .order("sort_order", { ascending: true });

  if (imagesError || !images?.length) {
    return NextResponse.json(
      { error: "No images found for this flow" },
      { status: 400 }
    );
  }

  const typedImages = images as FlowImage[];

  // Ensure all images have captions
  const uncaptioned = typedImages.filter((img) => !img.caption?.trim());
  if (uncaptioned.length > 0) {
    return NextResponse.json(
      { error: `${uncaptioned.length} image(s) are missing captions` },
      { status: 400 }
    );
  }

  const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/training/webhook`;
  const { steps, learning_rate } = typedFlow.training_config;

  // Submit async job to fal.ai — don't await completion, webhook handles it.
  // The SDK's Flux2TrainerInput type requires a zip via image_data_url, but the
  // live API also accepts individual image+caption pairs. Cast to bypass the
  // type constraint and use the richer payload the spec calls for.
  let queueResult;
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    queueResult = await (fal.queue as any).submit(FAL_TRAINER_MODEL, {
      input: {
        images: typedImages.map((img) => ({
          url: img.public_url,
          caption: img.caption,
        })),
        trigger_word: typedFlow.trigger_word,
        steps,
        learning_rate,
        is_style: false,
        create_masks: true,
      },
      webhookUrl,
    });
  } catch (err) {
    console.error("[POST /api/training/start] fal.ai submit error:", err);
    return NextResponse.json(
      { error: "Failed to submit training job" },
      { status: 502 }
    );
  }

  const estimatedDurationSec = estimateTrainingTime(steps, typedImages.length);
  const now = new Date().toISOString();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { error: updateError } = await (supabase as any)
    .from("lora_flows")
    .update({
      status: "training",
      fal_job_id: queueResult.request_id,
      training_started_at: now,
      estimated_duration_sec: estimatedDurationSec,
      error_message: null,
      updated_at: now,
    })
    .eq("id", flow_id);

  if (updateError) {
    console.error("[POST /api/training/start] Failed to update flow:", updateError);
    // Job was submitted — don't fail the response, webhook will still fire
  }

  return NextResponse.json({
    fal_job_id: queueResult.request_id,
    estimated_duration_sec: estimatedDurationSec,
  });
}
