import { NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";
import { ANTHROPIC_MODEL } from "@/lib/constants";
import type { GuidanceRequest, AiGuidance } from "@/types";

const SYSTEM_PROMPT = `You are an expert in training LoRA models for FLUX image generation.
Given a user's vision and theme for their LoRA, provide specific guidance:

1. recommended_image_count: number (typically 15-50)
2. shot_types: string[] — specific types of photos they should include
   (e.g., "front-facing with label visible", "45-degree angle showing cap detail",
   "product in-hand for scale reference", "close-up of texture/finish")
3. suggested_trigger_word: string — a unique, specific trigger word
4. background_tips: string — advice on background variety
5. lighting_tips: string — advice on lighting variation
6. common_mistakes: string[] — things to avoid
7. estimated_training_steps: number — recommended step count

Respond in JSON only.`;

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: GuidanceRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { vision, theme } = body;

  if (!vision?.trim() || !theme?.trim()) {
    return NextResponse.json(
      { error: "vision and theme are required" },
      { status: 400 }
    );
  }

  let message;
  try {
    message = await anthropic.messages.create({
      model: ANTHROPIC_MODEL,
      max_tokens: 2048,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: "user",
          content: `Vision: ${vision.trim()}\nTheme: ${theme.trim()}`,
        },
      ],
    });
  } catch (err) {
    console.error("[POST /api/ai/guidance] Anthropic error:", err);
    return NextResponse.json(
      { error: "Failed to generate guidance" },
      { status: 502 }
    );
  }

  const rawText =
    message.content[0].type === "text" ? message.content[0].text : "";

  let guidance: AiGuidance;
  try {
    // Claude may wrap the JSON in a markdown code block — strip it if so
    const jsonString = rawText
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/, "")
      .trim();
    guidance = JSON.parse(jsonString);
  } catch {
    console.error("[POST /api/ai/guidance] Failed to parse Claude response:", rawText);
    return NextResponse.json(
      { error: "Invalid response from AI" },
      { status: 502 }
    );
  }

  // Validate required fields are present
  const required: (keyof AiGuidance)[] = [
    "recommended_image_count",
    "shot_types",
    "suggested_trigger_word",
    "background_tips",
    "lighting_tips",
    "common_mistakes",
    "estimated_training_steps",
  ];
  for (const key of required) {
    if (guidance[key] === undefined) {
      console.error(`[POST /api/ai/guidance] Missing field: ${key}`, guidance);
      return NextResponse.json(
        { error: "Incomplete response from AI" },
        { status: 502 }
      );
    }
  }

  return NextResponse.json({ guidance });
}
