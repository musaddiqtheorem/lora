import { NextResponse } from "next/server";
import { fal } from "@fal-ai/client";
import { createClient } from "@/lib/supabase/server";
import { FAL_TRAINER_MODEL } from "@/lib/constants";
import type { LoraFlow, TrainingStatusResponse } from "@/types";

fal.config({ credentials: process.env.FAL_KEY });

export async function GET(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const flow_id = searchParams.get("flow_id");

  if (!flow_id) {
    return NextResponse.json({ error: "flow_id is required" }, { status: 400 });
  }

  // Fetch flow — RLS ensures ownership
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error: flowError } = await (supabase as any)
    .from("lora_flows")
    .select("id, status, fal_job_id, training_started_at, estimated_duration_sec")
    .eq("id", flow_id)
    .single();

  if (flowError || !flow) {
    return NextResponse.json({ error: "Flow not found" }, { status: 404 });
  }

  const typedFlow = flow as Pick<
    LoraFlow,
    "id" | "status" | "fal_job_id" | "training_started_at" | "estimated_duration_sec"
  >;

  // If the flow isn't actively training, return the current status directly
  if (typedFlow.status !== "training" || !typedFlow.fal_job_id) {
    const response: TrainingStatusResponse = {
      status: typedFlow.status,
      progress_percentage: typedFlow.status === "complete" ? 100 : null,
      estimated_remaining_sec: null,
    };
    return NextResponse.json(response);
  }

  // Poll fal.ai for the live job status
  let falStatus;
  try {
    falStatus = await fal.queue.status(FAL_TRAINER_MODEL, {
      requestId: typedFlow.fal_job_id,
      logs: false,
    });
  } catch (err) {
    console.error("[GET /api/training/status] fal.ai status error:", err);
    // Fall back to the stored status rather than erroring out
    const response: TrainingStatusResponse = {
      status: typedFlow.status,
      progress_percentage: null,
      estimated_remaining_sec: null,
    };
    return NextResponse.json(response);
  }

  // Derive a progress percentage from elapsed vs. estimated time
  let progress_percentage: number | null = null;
  let estimated_remaining_sec: number | null = null;

  if (typedFlow.training_started_at && typedFlow.estimated_duration_sec) {
    const elapsedSec =
      (Date.now() - new Date(typedFlow.training_started_at).getTime()) / 1000;
    const estimated = typedFlow.estimated_duration_sec;
    progress_percentage = Math.min(
      Math.round((elapsedSec / estimated) * 100),
      99 // cap at 99 until webhook confirms completion
    );
    estimated_remaining_sec = Math.max(
      0,
      Math.round(estimated - elapsedSec)
    );
  }

  // If fal reports completed, update the flow (belt-and-suspenders alongside webhook)
  if (falStatus.status === "COMPLETED") {
    progress_percentage = 100;
    estimated_remaining_sec = 0;

    // If our DB still shows "training", the webhook may have been delayed —
    // update status to "complete" optimistically. The webhook will also do this.
    if (typedFlow.status === "training") {
      const now = new Date().toISOString();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (supabase as any)
        .from("lora_flows")
        .update({
          status: "complete",
          training_completed_at: now,
          updated_at: now,
        })
        .eq("id", typedFlow.id);
    }
  }

  const response: TrainingStatusResponse = {
    status:
      falStatus.status === "COMPLETED"
        ? "complete"
        : typedFlow.status,
    progress_percentage,
    estimated_remaining_sec,
  };

  return NextResponse.json(response);
}
