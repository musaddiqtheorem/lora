import { NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";
import { ANTHROPIC_MODEL } from "@/lib/constants";
import type { CaptionsRequest, CaptionResult } from "@/types";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

function buildSystemPrompt(triggerWord: string, theme: string): string {
  return `You are writing training captions for a LoRA fine-tuning dataset.
The trigger word is: "${triggerWord}"
The theme is: "${theme}"

For each image, write a detailed caption that:
- Starts with "a photo of ${triggerWord}"
- Describes the subject precisely (shape, color, material, text on labels)
- Describes the angle/perspective
- Describes lighting conditions
- Describes the background/setting
- Uses natural language, not keywords
- Is 1-3 sentences long

Respond as JSON: { "captions": [{ "image_id": "...", "caption": "..." }] }`;
}

export async function POST(request: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: CaptionsRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { flow_id, trigger_word, theme, images } = body;

  if (!flow_id || !trigger_word?.trim() || !theme?.trim() || !images?.length) {
    return NextResponse.json(
      { error: "flow_id, trigger_word, theme, and images are required" },
      { status: 400 }
    );
  }

  // Verify the flow belongs to this user (RLS would also catch it, but fail early)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: flow, error: flowError } = await (supabase as any)
    .from("lora_flows")
    .select("id")
    .eq("id", flow_id)
    .single();

  if (flowError || !flow) {
    return NextResponse.json({ error: "Flow not found" }, { status: 404 });
  }

  // Build the multimodal message — interleave image + text prompt per image
  const userContent: Anthropic.MessageParam["content"] = images.flatMap(
    (img) => [
      {
        type: "image" as const,
        source: {
          type: "url" as const,
          url: img.public_url,
        },
      },
      {
        type: "text" as const,
        text: `Image ID: ${img.id}. Write a training caption for this image.`,
      },
    ]
  );

  let message: Anthropic.Message;
  try {
    message = await anthropic.messages.create({
      model: ANTHROPIC_MODEL,
      max_tokens: 4096,
      system: buildSystemPrompt(trigger_word.trim(), theme.trim()),
      messages: [{ role: "user", content: userContent }],
    });
  } catch (err) {
    console.error("[POST /api/ai/captions] Anthropic error:", err);
    return NextResponse.json(
      { error: "Failed to generate captions" },
      { status: 502 }
    );
  }

  const rawText =
    message.content[0].type === "text" ? message.content[0].text : "";

  let parsed: { captions: CaptionResult[] };
  try {
    const jsonString = rawText
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/, "")
      .trim();
    parsed = JSON.parse(jsonString);
  } catch {
    console.error("[POST /api/ai/captions] Failed to parse response:", rawText);
    return NextResponse.json(
      { error: "Invalid response from AI" },
      { status: 502 }
    );
  }

  if (!Array.isArray(parsed.captions)) {
    return NextResponse.json(
      { error: "Incomplete response from AI" },
      { status: 502 }
    );
  }

  // Persist ai_draft_caption on each flow_image row
  const updatePromises = parsed.captions.map((c: CaptionResult) =>
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (supabase as any)
      .from("flow_images")
      .update({ ai_draft_caption: c.caption, caption: c.caption })
      .eq("id", c.image_id)
      .eq("flow_id", flow_id)
  );

  await Promise.all(updatePromises);

  return NextResponse.json({ captions: parsed.captions });
}
