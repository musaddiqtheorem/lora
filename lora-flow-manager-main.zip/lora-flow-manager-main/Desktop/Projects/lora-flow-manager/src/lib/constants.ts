import type { FlowStatus, TrainingConfig } from "@/types";

// ---------------------------------------------------------------------------
// Flow status
// ---------------------------------------------------------------------------

export const FLOW_STATUSES = [
  "draft",
  "uploading",
  "captioning",
  "ready",
  "training",
  "complete",
  "failed",
] as const satisfies readonly FlowStatus[];

export const FLOW_STATUS_LABELS: Record<FlowStatus, string> = {
  draft: "Draft",
  uploading: "Uploading",
  captioning: "Captioning",
  ready: "Ready",
  training: "Training",
  complete: "Complete",
  failed: "Failed",
};

/** Tailwind classes for status badges */
export const FLOW_STATUS_COLORS: Record<
  FlowStatus,
  { bg: string; text: string; border: string }
> = {
  draft: {
    bg: "bg-stone-100",
    text: "text-stone-600",
    border: "border-stone-300",
  },
  uploading: {
    bg: "bg-blue-50",
    text: "text-blue-700",
    border: "border-blue-300",
  },
  captioning: {
    bg: "bg-amber-50",
    text: "text-amber-700",
    border: "border-amber-300",
  },
  ready: {
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    border: "border-emerald-300",
  },
  training: {
    bg: "bg-orange-50",
    text: "text-orange-700",
    border: "border-orange-300",
  },
  complete: {
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    border: "border-emerald-300",
  },
  failed: {
    bg: "bg-red-50",
    text: "text-red-700",
    border: "border-red-300",
  },
};

/** Left-border accent color for FlowCards */
export const FLOW_STATUS_BORDER_ACCENT: Record<FlowStatus, string> = {
  draft: "border-stone-300",
  uploading: "border-blue-400",
  captioning: "border-amber-400",
  ready: "border-emerald-400",
  training: "border-orange-400",
  complete: "border-emerald-500",
  failed: "border-red-400",
};

// ---------------------------------------------------------------------------
// Training defaults
// ---------------------------------------------------------------------------

export const DEFAULT_TRAINING_CONFIG: TrainingConfig = {
  steps: 1000,
  learning_rate: 0.0001,
  batch_size: 1,
};

export const TRAINING_STEPS_MIN = 500;
export const TRAINING_STEPS_MAX = 2000;
export const TRAINING_STEPS_DEFAULT = 1000;

export const LORA_SCALE_MIN = 0.5;
export const LORA_SCALE_MAX = 1.0;
export const LORA_SCALE_DEFAULT = 0.8;

/** Seconds per step (base, no image overhead) */
export const BASE_SECONDS_PER_STEP = 2;

/** Additional seconds per step per image above 20 */
export const IMAGE_OVERHEAD_PER_STEP = 0.05;

/** USD per step for FLUX.2 trainer on fal.ai */
export const COST_PER_STEP_USD = 0.008;

export function estimateTrainingTime(
  steps: number,
  imageCount: number
): number {
  const imageOverhead = Math.max(0, imageCount - 20) * IMAGE_OVERHEAD_PER_STEP;
  return Math.ceil(steps * (BASE_SECONDS_PER_STEP + imageOverhead));
}

export function estimateTrainingCost(steps: number): number {
  return steps * COST_PER_STEP_USD;
}

// ---------------------------------------------------------------------------
// Image upload
// ---------------------------------------------------------------------------

export const ACCEPTED_IMAGE_TYPES = {
  "image/jpeg": [".jpg", ".jpeg"],
  "image/png": [".png"],
  "image/webp": [".webp"],
};

export const MIN_IMAGES_TO_PROCEED = 10;
export const MAX_IMAGE_SIZE_MB = 20;
export const MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024;

export const STORAGE_BUCKET = "flow-images";

// ---------------------------------------------------------------------------
// AI models
// ---------------------------------------------------------------------------

export const ANTHROPIC_MODEL = "claude-sonnet-4-20250514";

export const FAL_TRAINER_MODEL = "fal-ai/flux-2-trainer";

export const FAL_GENERATION_MODELS = [
  { id: "fal-ai/flux-2/lora", label: "FLUX.2 LoRA (recommended)" },
  { id: "fal-ai/flux-lora", label: "FLUX.1 LoRA" },
] as const;

export const FAL_DEFAULT_GENERATION_MODEL = "fal-ai/flux-2/lora";

// ---------------------------------------------------------------------------
// Polling interval for training status (ms)
// ---------------------------------------------------------------------------

export const TRAINING_POLL_INTERVAL_MS = 30_000;

// ---------------------------------------------------------------------------
// Flow steps
// ---------------------------------------------------------------------------

export const FLOW_STEPS = [
  { step: 1, label: "Vision", path: "" },          // /flows/new or /flows/[id]
  { step: 2, label: "Upload", path: "upload" },
  { step: 3, label: "Captions", path: "caption" },
  { step: 4, label: "Train", path: "train" },
  { step: 5, label: "Test", path: "test" },
] as const;
