import type { Database } from "./database.types";

// This tests that Database["public"] satisfies the shape needed by supabase-js
type PublicSchema = Database["public"];

type AssertTables = PublicSchema["Tables"]["lora_flows"]["Insert"];
// hover-test: should not be `never`
type _Check = AssertTables extends never ? "ERROR: Insert is never" : "OK";
const _check: _Check = "OK";
