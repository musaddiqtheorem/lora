import type { AiGuidance, TrainingConfig, FlowStatus } from "@/types";

// Row types
interface LoraFlowRow {
  id: string;
  user_id: string;
  vision: string;
  theme: string;
  trigger_word: string;
  status: FlowStatus;
  ai_guidance: AiGuidance | null;
  training_config: TrainingConfig;
  fal_job_id: string | null;
  lora_url: string | null;
  training_started_at: string | null;
  training_completed_at: string | null;
  estimated_duration_sec: number | null;
  error_message: string | null;
  created_at: string;
  updated_at: string;
}

interface FlowImageRow {
  id: string;
  flow_id: string;
  storage_path: string;
  public_url: string;
  original_filename: string;
  caption: string;
  ai_draft_caption: string | null;
  sort_order: number;
  created_at: string;
}

interface LoraTestRow {
  id: string;
  flow_id: string;
  prompt: string;
  result_url: string;
  model_used: string;
  created_at: string;
}

// Insert types (DB-generated fields are optional)
interface LoraFlowInsert {
  id?: string;
  user_id: string;
  vision: string;
  theme: string;
  trigger_word: string;
  status: FlowStatus;
  ai_guidance?: AiGuidance | null;
  training_config: TrainingConfig;
  fal_job_id?: string | null;
  lora_url?: string | null;
  training_started_at?: string | null;
  training_completed_at?: string | null;
  estimated_duration_sec?: number | null;
  error_message?: string | null;
  created_at?: string;
  updated_at?: string;
}

interface FlowImageInsert {
  id?: string;
  flow_id: string;
  storage_path: string;
  public_url: string;
  original_filename: string;
  caption: string;
  ai_draft_caption?: string | null;
  sort_order: number;
  created_at?: string;
}

interface LoraTestInsert {
  id?: string;
  flow_id: string;
  prompt: string;
  result_url: string;
  model_used: string;
  created_at?: string;
}

export interface Database {
  public: {
    Tables: {
      lora_flows: {
        Row: LoraFlowRow;
        Insert: LoraFlowInsert;
        Update: Partial<LoraFlowRow>;
        Relationships: [];
      };
      flow_images: {
        Row: FlowImageRow;
        Insert: FlowImageInsert;
        Update: Partial<FlowImageRow>;
        Relationships: [];
      };
      lora_tests: {
        Row: LoraTestRow;
        Insert: LoraTestInsert;
        Update: Partial<LoraTestRow>;
        Relationships: [];
      };
    };
    // Empty maps must satisfy Record<string, GenericView/GenericFunction>.
    // Use the updatable-view shape (includes Insert/Update) so the `insert`
    // overload's `Relation$1 extends { Insert: unknown }` check passes on tables.
    Views: Record<string, {
      Row: Record<string, unknown>;
      Insert: Record<string, unknown>;
      Update: Record<string, unknown>;
      Relationships: [];
    }>;
    Functions: Record<string, {
      Args: Record<string, unknown>;
      Returns: unknown;
    }>;
    Enums: Record<string, string>;
  };
}
