"use client";

import { FLOW_STEPS } from "@/lib/constants";
import Link from "next/link";

interface FlowStepperProps {
  /** The flow ID — used to build href links for completed steps */
  flowId: string;
  /** 1-indexed current step number */
  currentStep: number;
}

export function FlowStepper({ flowId, currentStep }: FlowStepperProps) {
  return (
    <nav aria-label="Flow progress" className="w-full">
      <ol className="flex items-center">
        {FLOW_STEPS.map((step, index) => {
          const isCompleted = step.step < currentStep;
          const isCurrent = step.step === currentStep;
          const isUpcoming = step.step > currentStep;
          const isLast = index === FLOW_STEPS.length - 1;

          // Build href: completed steps are navigable
          const href =
            step.step === 1
              ? `/flows/${flowId}`
              : `/flows/${flowId}/${step.path}`;

          return (
            <li key={step.step} className="flex items-center flex-1 last:flex-none">
              {/* Step circle + label */}
              <div className="flex flex-col items-center gap-1.5">
                {isCompleted ? (
                  <Link
                    href={href}
                    className="flex h-8 w-8 items-center justify-center rounded-full transition-colors"
                    style={{
                      backgroundColor: "var(--color-accent)",
                      color: "#fff",
                    }}
                    aria-label={`${step.label} — completed`}
                  >
                    {/* Checkmark */}
                    <svg
                      className="h-4 w-4"
                      viewBox="0 0 16 16"
                      fill="none"
                      aria-hidden
                    >
                      <path
                        d="M3 8l3.5 3.5L13 5"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </Link>
                ) : (
                  <span
                    className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-semibold select-none"
                    style={
                      isCurrent
                        ? {
                            backgroundColor: "var(--color-accent)",
                            color: "#fff",
                            boxShadow: "0 0 0 3px var(--color-accent-light)",
                          }
                        : {
                            backgroundColor: "var(--color-surface)",
                            color: "var(--color-text-muted)",
                            border: "1.5px solid var(--color-border-strong)",
                          }
                    }
                    aria-current={isCurrent ? "step" : undefined}
                  >
                    {step.step}
                  </span>
                )}

                {/* Step label */}
                <span
                  className="text-xs font-medium whitespace-nowrap"
                  style={{
                    color: isUpcoming
                      ? "var(--color-text-muted)"
                      : isCurrent
                      ? "var(--color-accent)"
                      : "var(--color-text-secondary)",
                  }}
                >
                  {step.label}
                </span>
              </div>

              {/* Connector line — not after the last step */}
              {!isLast && (
                <div
                  className="flex-1 h-px mx-3 mb-5"
                  style={{
                    backgroundColor: isCompleted
                      ? "var(--color-accent)"
                      : "var(--color-border-strong)",
                    opacity: isCompleted ? 1 : 0.6,
                  }}
                  aria-hidden
                />
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
