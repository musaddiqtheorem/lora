"use client";

import type { AiGuidance } from "@/types";

interface GuidancePanelProps {
  guidance: AiGuidance | null;
  loading?: boolean;
}

export function GuidancePanel({ guidance, loading = false }: GuidancePanelProps) {
  if (loading) {
    return (
      <div
        className="h-full rounded-lg p-6 flex flex-col gap-4"
        style={{
          backgroundColor: "var(--color-surface)",
          border: "1px solid var(--color-border)",
        }}
      >
        <div className="flex items-center gap-2">
          <PulsingDot />
          <span
            className="text-sm font-medium"
            style={{ color: "var(--color-text-secondary)" }}
          >
            Analyzing your vision…
          </span>
        </div>
        <div className="flex flex-col gap-3">
          {[80, 60, 70, 55].map((w, i) => (
            <SkeletonLine key={i} widthPct={w} />
          ))}
        </div>
      </div>
    );
  }

  if (!guidance) {
    return (
      <div
        className="h-full rounded-lg p-6 flex flex-col items-center justify-center gap-3 text-center"
        style={{
          backgroundColor: "var(--color-surface)",
          border: "1.5px dashed var(--color-border-strong)",
        }}
      >
        <AdvisorIcon />
        <div>
          <p
            className="text-sm font-medium"
            style={{ color: "var(--color-text-secondary)" }}
          >
            AI guidance will appear here
          </p>
          <p
            className="mt-1 text-xs"
            style={{ color: "var(--color-text-muted)" }}
          >
            Fill in your vision and theme, then click&nbsp;
            <span className="font-medium" style={{ color: "var(--color-accent)" }}>
              Get AI Guidance
            </span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="h-full rounded-lg overflow-y-auto"
      style={{
        backgroundColor: "var(--color-surface)",
        border: "1px solid var(--color-border)",
      }}
    >
      {/* Header */}
      <div
        className="px-5 py-4 flex items-center gap-2"
        style={{ borderBottom: "1px solid var(--color-border)" }}
      >
        <AdvisorIcon small />
        <span
          className="text-sm font-semibold"
          style={{ color: "var(--color-text-primary)" }}
        >
          Training Guidance
        </span>
      </div>

      <div className="px-5 py-4 flex flex-col gap-5">
        {/* Recommended image count — prominent number */}
        <div
          className="rounded-md p-4 flex items-center gap-4"
          style={{ backgroundColor: "var(--color-accent-light)" }}
        >
          <span
            className="text-3xl font-bold tabular-nums leading-none"
            style={{ color: "var(--color-accent)" }}
          >
            {guidance.recommended_image_count}
          </span>
          <div>
            <p
              className="text-sm font-medium"
              style={{ color: "var(--color-accent)" }}
            >
              Recommended images
            </p>
            <p
              className="text-xs mt-0.5"
              style={{ color: "var(--color-text-secondary)" }}
            >
              {guidance.estimated_training_steps.toLocaleString()} training steps
            </p>
          </div>
        </div>

        {/* Trigger word suggestion */}
        {guidance.suggested_trigger_word && (
          <Section label="Suggested trigger word">
            <code
              className="inline-block rounded px-2 py-1 text-sm"
              style={{
                fontFamily: "var(--font-mono)",
                backgroundColor: "var(--color-accent-light)",
                color: "var(--color-accent)",
              }}
            >
              {guidance.suggested_trigger_word}
            </code>
          </Section>
        )}

        {/* Shot types checklist */}
        <Section label="Shot types to capture">
          <ul className="flex flex-col gap-1.5">
            {guidance.shot_types.map((shot, i) => (
              <li key={i} className="flex items-start gap-2">
                <CheckIcon />
                <span
                  className="text-xs leading-relaxed"
                  style={{ color: "var(--color-text-secondary)" }}
                >
                  {shot}
                </span>
              </li>
            ))}
          </ul>
        </Section>

        {/* Lighting tips */}
        <Section label="Lighting">
          <p
            className="text-xs leading-relaxed"
            style={{ color: "var(--color-text-secondary)" }}
          >
            {guidance.lighting_tips}
          </p>
        </Section>

        {/* Background tips */}
        <Section label="Backgrounds">
          <p
            className="text-xs leading-relaxed"
            style={{ color: "var(--color-text-secondary)" }}
          >
            {guidance.background_tips}
          </p>
        </Section>

        {/* Common mistakes */}
        <Section label="Avoid these mistakes">
          <ul className="flex flex-col gap-1.5">
            {guidance.common_mistakes.map((mistake, i) => (
              <li key={i} className="flex items-start gap-2">
                <WarnIcon />
                <span
                  className="text-xs leading-relaxed"
                  style={{ color: "var(--color-text-secondary)" }}
                >
                  {mistake}
                </span>
              </li>
            ))}
          </ul>
        </Section>
      </div>
    </div>
  );
}

// ---- Sub-components --------------------------------------------------------

function Section({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <h4
        className="text-xs font-semibold uppercase tracking-wide"
        style={{ color: "var(--color-text-muted)" }}
      >
        {label}
      </h4>
      {children}
    </div>
  );
}

function CheckIcon() {
  return (
    <svg
      className="mt-0.5 shrink-0 h-3.5 w-3.5"
      viewBox="0 0 14 14"
      fill="none"
      aria-hidden
    >
      <circle cx="7" cy="7" r="7" fill="var(--color-status-ready-bg)" />
      <path
        d="M4 7l2 2 4-4"
        stroke="var(--color-status-ready-text)"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function WarnIcon() {
  return (
    <svg
      className="mt-0.5 shrink-0 h-3.5 w-3.5"
      viewBox="0 0 14 14"
      fill="none"
      aria-hidden
    >
      <circle cx="7" cy="7" r="7" fill="var(--color-status-failed-bg)" />
      <path
        d="M7 4.5v3M7 9.5v.5"
        stroke="var(--color-status-failed-text)"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

function AdvisorIcon({ small = false }: { small?: boolean }) {
  const size = small ? "h-4 w-4" : "h-8 w-8";
  return (
    <svg
      className={`${size} shrink-0`}
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden
    >
      <rect width="32" height="32" rx="8" fill="var(--color-accent-light)" />
      <path
        d="M10 22c0-3.314 2.686-6 6-6s6 2.686 6 6"
        stroke="var(--color-accent)"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <circle cx="16" cy="13" r="3" stroke="var(--color-accent)" strokeWidth="1.5" />
    </svg>
  );
}

function PulsingDot() {
  return (
    <span className="relative flex h-2 w-2 shrink-0">
      <span
        className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
        style={{ backgroundColor: "var(--color-accent)" }}
      />
      <span
        className="relative inline-flex rounded-full h-2 w-2"
        style={{ backgroundColor: "var(--color-accent)" }}
      />
    </span>
  );
}

function SkeletonLine({ widthPct }: { widthPct: number }) {
  return (
    <div
      className="h-3 rounded animate-pulse"
      style={{
        width: `${widthPct}%`,
        backgroundColor: "var(--color-border)",
      }}
    />
  );
}
