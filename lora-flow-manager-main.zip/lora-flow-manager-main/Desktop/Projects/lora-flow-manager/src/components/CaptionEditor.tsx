"use client";

import Image from "next/image";
import type { FlowImage } from "@/types";

interface CaptionEditorProps {
  image: FlowImage;
  triggerWord: string;
  loading?: boolean;
  onChange: (imageId: string, caption: string) => void;
}

export function CaptionEditor({
  image,
  triggerWord,
  loading = false,
  onChange,
}: CaptionEditorProps) {
  const hasCaption = image.caption.trim().length > 0;
  const hasTrigger =
    triggerWord.trim().length > 0 &&
    image.caption.toLowerCase().includes(triggerWord.toLowerCase());
  const hasAiDraft =
    image.ai_draft_caption !== null && image.ai_draft_caption.trim().length > 0;
  const isDirty =
    hasAiDraft && image.caption.trim() !== image.ai_draft_caption!.trim();
  const charCount = image.caption.length;

  function handleReset() {
    if (hasAiDraft) onChange(image.id, image.ai_draft_caption!);
  }

  return (
    <div
      className="flex flex-col sm:flex-row gap-0 rounded-lg overflow-hidden"
      style={{
        border: "1px solid var(--color-border)",
        backgroundColor: "var(--color-surface)",
      }}
    >
      {/* ---- Thumbnail (left / top) ---- */}
      <div
        className="relative shrink-0 sm:w-40 w-full aspect-square sm:aspect-auto"
        style={{ backgroundColor: "var(--color-background)" }}
      >
        <Image
          src={image.public_url}
          alt={image.original_filename}
          fill
          className="object-cover"
          sizes="160px"
          unoptimized
        />
        {loading && (
          <div
            className="absolute inset-0 flex items-center justify-center"
            style={{ backgroundColor: "rgba(255,255,255,0.75)" }}
          >
            <Spinner />
          </div>
        )}
      </div>

      {/* ---- Caption area (right / bottom) ---- */}
      <div className="flex flex-col flex-1 p-3 gap-2 min-w-0">
        {/* Filename + indicators row */}
        <div className="flex items-center justify-between gap-2">
          <p
            className="text-xs truncate"
            style={{ color: "var(--color-text-muted)" }}
            title={image.original_filename}
          >
            {image.original_filename}
          </p>
          <div className="flex items-center gap-1.5 shrink-0">
            {/* AI-drafted indicator */}
            {hasAiDraft && !isDirty && (
              <span
                className="text-xs rounded-full px-2 py-0.5"
                style={{
                  backgroundColor: "var(--color-accent-light)",
                  color: "var(--color-accent)",
                }}
              >
                AI draft
              </span>
            )}
            {/* Trigger word indicator */}
            {hasCaption && (
              hasTrigger ? (
                <TriggerCheck ok />
              ) : (
                <TriggerCheck ok={false} word={triggerWord} />
              )
            )}
          </div>
        </div>

        {/* Textarea */}
        <textarea
          value={image.caption}
          onChange={(e) => onChange(image.id, e.target.value)}
          disabled={loading}
          rows={4}
          placeholder={
            triggerWord
              ? `a photo of ${triggerWord} — describe angle, lighting, background…`
              : "Write a caption describing this image…"
          }
          className="w-full flex-1 rounded-md px-3 py-2 text-sm resize-none outline-none transition-colors disabled:opacity-60"
          style={{
            backgroundColor: "var(--color-background)",
            border: "1px solid var(--color-border-strong)",
            color: "var(--color-text-primary)",
            fontFamily: "inherit",
          }}
        />

        {/* Footer: char count + reset button */}
        <div className="flex items-center justify-between gap-2">
          <span
            className="text-xs tabular-nums"
            style={{ color: "var(--color-text-muted)" }}
          >
            {charCount} chars
          </span>
          {isDirty && hasAiDraft && (
            <button
              type="button"
              onClick={handleReset}
              className="text-xs underline underline-offset-2 transition-opacity hover:opacity-70"
              style={{ color: "var(--color-text-secondary)" }}
            >
              Reset to AI draft
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ---- Local helpers ---------------------------------------------------------

function TriggerCheck({ ok, word }: { ok: boolean; word?: string }) {
  if (ok) {
    return (
      <span
        title="Trigger word present"
        className="flex items-center gap-1 text-xs rounded-full px-1.5 py-0.5"
        style={{
          backgroundColor: "var(--color-status-ready-bg)",
          color: "var(--color-status-ready-text)",
        }}
      >
        <svg className="h-3 w-3" viewBox="0 0 12 12" fill="none" aria-hidden>
          <path
            d="M2 6l3 3 5-5"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        trigger
      </span>
    );
  }
  return (
    <span
      title={word ? `Missing trigger word: ${word}` : "Trigger word missing"}
      className="flex items-center gap-1 text-xs rounded-full px-1.5 py-0.5"
      style={{
        backgroundColor: "var(--color-status-failed-bg)",
        color: "var(--color-status-failed-text)",
      }}
    >
      <svg className="h-3 w-3" viewBox="0 0 12 12" fill="none" aria-hidden>
        <path
          d="M6 3v4M6 8.5v.5"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      </svg>
      trigger
    </span>
  );
}

function Spinner() {
  return (
    <svg
      className="h-5 w-5 animate-spin"
      viewBox="0 0 24 24"
      fill="none"
      aria-label="Loading"
    >
      <circle
        className="opacity-25"
        cx="12" cy="12" r="10"
        stroke="var(--color-accent)"
        strokeWidth="4"
      />
      <path
        className="opacity-75"
        fill="var(--color-accent)"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
      />
    </svg>
  );
}
