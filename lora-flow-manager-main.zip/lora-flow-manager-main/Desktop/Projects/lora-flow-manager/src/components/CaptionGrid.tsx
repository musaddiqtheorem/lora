"use client";

import { CaptionEditor } from "@/components/CaptionEditor";
import type { FlowImage } from "@/types";

interface CaptionGridProps {
  images: FlowImage[];
  triggerWord: string;
  /** Set of image IDs currently being captioned by AI */
  loadingIds?: Set<string>;
  onCaptionChange: (imageId: string, caption: string) => void;
}

export function CaptionGrid({
  images,
  triggerWord,
  loadingIds = new Set(),
  onCaptionChange,
}: CaptionGridProps) {
  if (images.length === 0) {
    return (
      <div
        className="rounded-lg py-16 flex flex-col items-center gap-2 text-center"
        style={{
          border: "1.5px dashed var(--color-border-strong)",
        }}
      >
        <p
          className="text-sm font-medium"
          style={{ color: "var(--color-text-secondary)" }}
        >
          No images yet
        </p>
        <p
          className="text-xs"
          style={{ color: "var(--color-text-muted)" }}
        >
          Go back to the upload step to add images
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {images.map((image) => (
        <CaptionEditor
          key={image.id}
          image={image}
          triggerWord={triggerWord}
          loading={loadingIds.has(image.id)}
          onChange={onCaptionChange}
        />
      ))}
    </div>
  );
}
