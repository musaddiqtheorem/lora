import * as React from "react";

// ---- Input ----------------------------------------------------------------

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, hint, id, className = "", style, ...props }, ref) => {
    const inputId = id ?? label?.toLowerCase().replace(/\s+/g, "-");

    return (
      <div className="flex flex-col gap-1.5">
        {label && (
          <label
            htmlFor={inputId}
            className="text-sm font-medium"
            style={{ color: "var(--color-text-primary)" }}
          >
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          className={`w-full rounded-md px-3 py-2 text-sm outline-none transition-colors placeholder:text-[var(--color-text-muted)] focus:ring-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
          style={{
            backgroundColor: "var(--color-surface)",
            border: error
              ? "1px solid #dc2626"
              : "1px solid var(--color-border-strong)",
            color: "var(--color-text-primary)",
            // @ts-expect-error custom property
            "--tw-ring-color": "var(--color-accent)",
            ...style,
          }}
          aria-invalid={!!error}
          aria-describedby={
            error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined
          }
          {...props}
        />
        {error && (
          <p
            id={`${inputId}-error`}
            className="text-xs"
            style={{ color: "#dc2626" }}
            role="alert"
          >
            {error}
          </p>
        )}
        {hint && !error && (
          <p
            id={`${inputId}-hint`}
            className="text-xs"
            style={{ color: "var(--color-text-muted)" }}
          >
            {hint}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";

// ---- Textarea -------------------------------------------------------------

interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, hint, id, className = "", style, ...props }, ref) => {
    const inputId = id ?? label?.toLowerCase().replace(/\s+/g, "-");

    return (
      <div className="flex flex-col gap-1.5">
        {label && (
          <label
            htmlFor={inputId}
            className="text-sm font-medium"
            style={{ color: "var(--color-text-primary)" }}
          >
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          id={inputId}
          className={`w-full rounded-md px-3 py-2 text-sm outline-none transition-colors resize-y placeholder:text-[var(--color-text-muted)] focus:ring-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
          style={{
            backgroundColor: "var(--color-surface)",
            border: error
              ? "1px solid #dc2626"
              : "1px solid var(--color-border-strong)",
            color: "var(--color-text-primary)",
            // @ts-expect-error custom property
            "--tw-ring-color": "var(--color-accent)",
            ...style,
          }}
          aria-invalid={!!error}
          aria-describedby={
            error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined
          }
          {...props}
        />
        {error && (
          <p
            id={`${inputId}-error`}
            className="text-xs"
            style={{ color: "#dc2626" }}
            role="alert"
          >
            {error}
          </p>
        )}
        {hint && !error && (
          <p
            id={`${inputId}-hint`}
            className="text-xs"
            style={{ color: "var(--color-text-muted)" }}
          >
            {hint}
          </p>
        )}
      </div>
    );
  }
);

Textarea.displayName = "Textarea";
