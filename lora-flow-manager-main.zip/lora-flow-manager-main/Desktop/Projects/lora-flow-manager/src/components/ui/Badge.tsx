import * as React from "react";
import type { FlowStatus } from "@/types";

// ---- Generic Badge --------------------------------------------------------

interface BadgeProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export function Badge({ children, className = "", style }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${className}`}
      style={style}
    >
      {children}
    </span>
  );
}

// ---- Status Badge ---------------------------------------------------------

interface StatusBadgeProps {
  status: FlowStatus;
  /** Show an animated pulse dot on "training" status */
  showPulse?: boolean;
}

const statusConfig: Record<
  FlowStatus,
  { label: string; bg: string; text: string; border: string }
> = {
  draft: {
    label: "Draft",
    bg: "var(--color-status-draft-bg)",
    text: "var(--color-status-draft-text)",
    border: "var(--color-status-draft-border)",
  },
  uploading: {
    label: "Uploading",
    bg: "var(--color-status-uploading-bg)",
    text: "var(--color-status-uploading-text)",
    border: "var(--color-status-uploading-border)",
  },
  captioning: {
    label: "Captioning",
    bg: "var(--color-status-captioning-bg)",
    text: "var(--color-status-captioning-text)",
    border: "var(--color-status-captioning-border)",
  },
  ready: {
    label: "Ready",
    bg: "var(--color-status-ready-bg)",
    text: "var(--color-status-ready-text)",
    border: "var(--color-status-ready-border)",
  },
  training: {
    label: "Training",
    bg: "var(--color-status-training-bg)",
    text: "var(--color-status-training-text)",
    border: "var(--color-status-training-border)",
  },
  complete: {
    label: "Complete",
    bg: "var(--color-status-complete-bg)",
    text: "var(--color-status-complete-text)",
    border: "var(--color-status-complete-border)",
  },
  failed: {
    label: "Failed",
    bg: "var(--color-status-failed-bg)",
    text: "var(--color-status-failed-text)",
    border: "var(--color-status-failed-border)",
  },
};

export function StatusBadge({ status, showPulse = true }: StatusBadgeProps) {
  const cfg = statusConfig[status];
  const isTraining = status === "training";

  return (
    <Badge
      style={{
        backgroundColor: cfg.bg,
        color: cfg.text,
        border: `1px solid ${cfg.border}`,
      }}
    >
      {isTraining && showPulse && (
        <span className="relative flex h-1.5 w-1.5" aria-hidden>
          <span
            className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
            style={{ backgroundColor: cfg.text }}
          />
          <span
            className="relative inline-flex rounded-full h-1.5 w-1.5"
            style={{ backgroundColor: cfg.text }}
          />
        </span>
      )}
      {cfg.label}
    </Badge>
  );
}
