"use client";

import Link from "next/link";
import type { LoraFlow } from "@/types";
import { StatusBadge } from "@/components/ui/Badge";

interface FlowCardProps {
  flow: LoraFlow;
  imageCount?: number;
}

// Left-border accent per status
const borderAccent: Record<string, string> = {
  draft: "var(--color-status-draft-border)",
  uploading: "var(--color-status-uploading-border)",
  captioning: "var(--color-status-captioning-border)",
  ready: "var(--color-status-ready-border)",
  training: "var(--color-status-training-border)",
  complete: "var(--color-status-complete-border)",
  failed: "var(--color-status-failed-border)",
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

// Where to navigate based on current step
function flowHref(flow: LoraFlow) {
  switch (flow.status) {
    case "draft":
      return `/flows/${flow.id}`;
    case "uploading":
      return `/flows/${flow.id}/upload`;
    case "captioning":
      return `/flows/${flow.id}/caption`;
    case "ready":
      return `/flows/${flow.id}/caption`;
    case "training":
      return `/flows/${flow.id}/train`;
    case "complete":
      return `/flows/${flow.id}/test`;
    case "failed":
      return `/flows/${flow.id}/train`;
  }
}

export function FlowCard({ flow, imageCount = 0 }: FlowCardProps) {
  const accent = borderAccent[flow.status] ?? "var(--color-border-strong)";
  const href = flowHref(flow);

  // Truncate theme to ~60 chars for the card title
  const title =
    flow.theme.length > 60 ? flow.theme.slice(0, 57) + "…" : flow.theme;

  return (
    <Link
      href={href}
      className="group block rounded-lg transition-shadow hover:shadow-md"
      style={{
        backgroundColor: "var(--color-surface)",
        border: "1px solid var(--color-border)",
        borderLeft: `3px solid ${accent}`,
        textDecoration: "none",
      }}
    >
      <div className="p-5 flex flex-col gap-3">
        {/* Top row: status badge + date */}
        <div className="flex items-center justify-between gap-2">
          <StatusBadge status={flow.status} />
          <span
            className="text-xs tabular-nums"
            style={{ color: "var(--color-text-muted)" }}
          >
            {formatDate(flow.created_at)}
          </span>
        </div>

        {/* Theme as title */}
        <div>
          <h3
            className="text-sm font-semibold leading-snug line-clamp-2"
            style={{ color: "var(--color-text-primary)" }}
          >
            {title}
          </h3>
          {flow.vision && (
            <p
              className="mt-1 text-xs leading-relaxed line-clamp-2"
              style={{ color: "var(--color-text-secondary)" }}
            >
              {flow.vision}
            </p>
          )}
        </div>

        {/* Footer row: trigger word + image count */}
        <div className="flex items-center justify-between gap-2 pt-1">
          {flow.trigger_word ? (
            <code
              className="rounded px-1.5 py-0.5 text-xs"
              style={{
                fontFamily: "var(--font-mono)",
                backgroundColor: "var(--color-accent-light)",
                color: "var(--color-accent)",
              }}
            >
              {flow.trigger_word}
            </code>
          ) : (
            <span />
          )}
          <span
            className="text-xs"
            style={{ color: "var(--color-text-muted)" }}
          >
            {imageCount} {imageCount === 1 ? "image" : "images"}
          </span>
        </div>
      </div>
    </Link>
  );
}
