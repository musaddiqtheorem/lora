"use client";

import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import Image from "next/image";
import { createClient } from "@/lib/supabase/client";
import {
  ACCEPTED_IMAGE_TYPES,
  MAX_IMAGE_SIZE_BYTES,
  MAX_IMAGE_SIZE_MB,
  STORAGE_BUCKET,
} from "@/lib/constants";
import type { FlowImage } from "@/types";

// ---- Types -----------------------------------------------------------------

interface UploadItem {
  file: File;
  previewUrl: string;
  /** undefined = queued, 0–99 = uploading, 100 = done, -1 = error */
  progress: number;
  error?: string;
  flowImage?: FlowImage;
}

interface ImageUploaderProps {
  flowId: string;
  userId: string;
  existingImages: FlowImage[];
  onImagesChange: (images: FlowImage[]) => void;
}

// ---- Component -------------------------------------------------------------

export function ImageUploader({
  flowId,
  userId,
  existingImages,
  onImagesChange,
}: ImageUploaderProps) {
  const [uploads, setUploads] = useState<UploadItem[]>([]);
  const supabase = createClient();

  // Merge committed images + in-progress uploads for display
  const committedImages = existingImages;
  const activeUploads = uploads.filter((u) => u.progress < 100);

  function updateUpload(previewUrl: string, patch: Partial<UploadItem>) {
    setUploads((prev) =>
      prev.map((u) => (u.previewUrl === previewUrl ? { ...u, ...patch } : u))
    );
  }

  async function uploadFile(file: File): Promise<FlowImage | null> {
    const ext = file.name.split(".").pop() ?? "jpg";
    const filename = `${crypto.randomUUID()}.${ext}`;
    const storagePath = `${userId}/${flowId}/${filename}`;

    // Track item
    const previewUrl = URL.createObjectURL(file);
    setUploads((prev) => [
      ...prev,
      { file, previewUrl, progress: 0 },
    ]);

    // Upload to Supabase Storage
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error: storageError } = await (supabase as any).storage
      .from(STORAGE_BUCKET)
      .upload(storagePath, file, {
        cacheControl: "3600",
        upsert: false,
      });

    if (storageError) {
      updateUpload(previewUrl, { progress: -1, error: storageError.message });
      return null;
    }

    updateUpload(previewUrl, { progress: 70 });

    // Get the public URL
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: urlData } = (supabase as any).storage
      .from(STORAGE_BUCKET)
      .getPublicUrl(storagePath);

    const publicUrl: string = urlData?.publicUrl ?? "";

    // Insert flow_images row
    const sortOrder = existingImages.length + uploads.filter((u) => u.progress === 100).length;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: imageRow, error: dbError } = await (supabase as any)
      .from("flow_images")
      .insert({
        flow_id: flowId,
        storage_path: storagePath,
        public_url: publicUrl,
        original_filename: file.name,
        caption: "",
        ai_draft_caption: null,
        sort_order: sortOrder,
      })
      .select()
      .single();

    if (dbError) {
      updateUpload(previewUrl, { progress: -1, error: dbError.message });
      return null;
    }

    updateUpload(previewUrl, { progress: 100, flowImage: imageRow as FlowImage });
    return imageRow as FlowImage;
  }

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      const results = await Promise.all(acceptedFiles.map(uploadFile));
      const newImages = results.filter(Boolean) as FlowImage[];
      if (newImages.length > 0) {
        onImagesChange([...existingImages, ...newImages]);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [existingImages, flowId, userId]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_IMAGE_TYPES,
    maxSize: MAX_IMAGE_SIZE_BYTES,
    multiple: true,
  });

  async function removeImage(image: FlowImage) {
    // Delete from Storage
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any).storage.from(STORAGE_BUCKET).remove([image.storage_path]);
    // Delete DB row
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any).from("flow_images").delete().eq("id", image.id);
    onImagesChange(existingImages.filter((img) => img.id !== image.id));
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Drop zone */}
      <div
        {...getRootProps()}
        className="relative cursor-pointer rounded-xl transition-colors"
        style={{
          border: isDragActive
            ? "2px solid var(--color-accent)"
            : "2px dashed var(--color-border-strong)",
          backgroundColor: isDragActive
            ? "var(--color-accent-light)"
            : "var(--color-surface)",
          padding: "2.5rem 1.5rem",
        }}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center gap-3 text-center pointer-events-none">
          <UploadIcon active={isDragActive} />
          <div>
            <p
              className="text-sm font-medium"
              style={{
                color: isDragActive
                  ? "var(--color-accent)"
                  : "var(--color-text-primary)",
              }}
            >
              {isDragActive ? "Drop images here" : "Drag & drop images"}
            </p>
            <p
              className="mt-0.5 text-xs"
              style={{ color: "var(--color-text-muted)" }}
            >
              or{" "}
              <span
                className="underline"
                style={{ color: "var(--color-accent)" }}
              >
                browse files
              </span>
              {" "}— JPG, PNG, WebP up to {MAX_IMAGE_SIZE_MB} MB each
            </p>
          </div>
        </div>
      </div>

      {/* In-progress uploads */}
      {activeUploads.length > 0 && (
        <div className="flex flex-col gap-2">
          {activeUploads.map((u) => (
            <UploadProgressRow key={u.previewUrl} item={u} />
          ))}
        </div>
      )}

      {/* Committed image grid */}
      {committedImages.length > 0 && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {committedImages.map((img) => (
            <ThumbnailCard
              key={img.id}
              image={img}
              onRemove={() => removeImage(img)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ---- Sub-components --------------------------------------------------------

function UploadProgressRow({ item }: { item: UploadItem }) {
  const isError = item.progress === -1;
  return (
    <div
      className="flex items-center gap-3 rounded-md px-3 py-2"
      style={{
        backgroundColor: isError
          ? "var(--color-status-failed-bg)"
          : "var(--color-surface)",
        border: `1px solid ${isError ? "var(--color-status-failed-border)" : "var(--color-border)"}`,
      }}
    >
      {/* Mini preview */}
      <div
        className="relative h-9 w-9 shrink-0 rounded overflow-hidden"
        style={{ backgroundColor: "var(--color-background)" }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={item.previewUrl}
          alt=""
          className="h-full w-full object-cover"
        />
      </div>

      <div className="flex-1 min-w-0">
        <p
          className="text-xs font-medium truncate"
          style={{
            color: isError
              ? "var(--color-status-failed-text)"
              : "var(--color-text-primary)",
          }}
        >
          {item.file.name}
        </p>
        {isError ? (
          <p
            className="text-xs"
            style={{ color: "var(--color-status-failed-text)" }}
          >
            {item.error ?? "Upload failed"}
          </p>
        ) : (
          <div
            className="mt-1 h-1 rounded-full overflow-hidden"
            style={{ backgroundColor: "var(--color-border)" }}
          >
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${item.progress}%`,
                backgroundColor: "var(--color-accent)",
              }}
            />
          </div>
        )}
      </div>

      <span
        className="text-xs tabular-nums shrink-0"
        style={{
          color: isError
            ? "var(--color-status-failed-text)"
            : "var(--color-text-muted)",
        }}
      >
        {isError ? "Error" : `${item.progress}%`}
      </span>
    </div>
  );
}

function ThumbnailCard({
  image,
  onRemove,
}: {
  image: FlowImage;
  onRemove: () => void;
}) {
  const [removing, setRemoving] = useState(false);

  async function handleRemove() {
    setRemoving(true);
    await onRemove();
  }

  const fileSizeKb = null; // not stored; omit rather than show 0

  return (
    <div
      className="group relative rounded-lg overflow-hidden"
      style={{
        border: "1px solid var(--color-border)",
        backgroundColor: "var(--color-surface)",
      }}
    >
      {/* Thumbnail */}
      <div className="relative aspect-square w-full">
        <Image
          src={image.public_url}
          alt={image.original_filename}
          fill
          className="object-cover"
          sizes="(max-width: 640px) 50vw, (max-width: 768px) 33vw, 25vw"
          unoptimized
        />
      </div>

      {/* Filename */}
      <div
        className="px-2 py-1.5"
        style={{ borderTop: "1px solid var(--color-border)" }}
      >
        <p
          className="text-xs truncate"
          style={{ color: "var(--color-text-secondary)" }}
          title={image.original_filename}
        >
          {image.original_filename}
        </p>
        {fileSizeKb && (
          <p
            className="text-xs tabular-nums"
            style={{ color: "var(--color-text-muted)" }}
          >
            {fileSizeKb} KB
          </p>
        )}
      </div>

      {/* Remove button — appears on hover */}
      <button
        onClick={handleRemove}
        disabled={removing}
        className="absolute top-1.5 right-1.5 flex h-6 w-6 items-center justify-center rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
        style={{
          backgroundColor: "rgba(0,0,0,0.65)",
          color: "#fff",
        }}
        aria-label={`Remove ${image.original_filename}`}
      >
        {removing ? (
          <svg className="h-3 w-3 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden>
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        ) : (
          <svg className="h-3 w-3" viewBox="0 0 12 12" fill="none" aria-hidden>
            <path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        )}
      </button>
    </div>
  );
}

function UploadIcon({ active }: { active: boolean }) {
  return (
    <div
      className="flex h-12 w-12 items-center justify-center rounded-xl transition-colors"
      style={{
        backgroundColor: active
          ? "var(--color-accent)"
          : "var(--color-accent-light)",
      }}
    >
      <svg
        className="h-6 w-6"
        viewBox="0 0 24 24"
        fill="none"
        aria-hidden
        style={{ color: active ? "#fff" : "var(--color-accent)" }}
      >
        <path
          d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M12 4v12M8 8l4-4 4 4"
          stroke="currentColor"
          strokeWidth="1.75"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}
